# VidGrab (Android natif)

Kotlin 2.0.20 · Jetpack Compose (BOM 2024.09.03) · Material 3 · Media3 1.4.1 · WorkManager 2.9.1 · OkHttp 4.12

## Ouvrir le projet
1. Android Studio (Koala+), JDK 17.
2. `File > Open` sur ce dossier `android/` : le wrapper Gradle 8.9 est généré à la synchronisation
   (ou `gradle wrapper --gradle-version 8.9`).
3. Lancer sur un appareil / émulateur API 29+.

## Architecture
- `web/` : `TabManager` (WebView + `MutableContextWrapper`), `VideoSniffer`, `AdBlock`
- `download/` : `DownloadCenter` (MAX_PARALLEL = 2), `DirectDownloader` (micro-blocs 3 Mo × 6-8 workers),
  `HlsDownloader` (+ `HlsParser`, AES-128, Media3 Transformer), `DownloadService` (dataSync),
  `KeepAliveWorker` (15 min, idempotent), `MediaStoreSaver` (Movies/VidGrab)
- `data/` : favoris, historique, PIN SHA-256 salé, bibliothèque, suggestions Google
- `player/` : `PlayerActivity` (ExoPlayer plein écran)
- `ui/` : écrans Compose (Onglet / Progression / Terminé)

> Le code n'a pas pu être compilé dans l'environnement de génération (pas de SDK Android) :
> prévoyez d'éventuels petits ajustements à la première synchronisation.
