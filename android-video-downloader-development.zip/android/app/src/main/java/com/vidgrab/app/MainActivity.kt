package com.vidgrab.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.vidgrab.app.ui.AppRoot
import com.vidgrab.app.ui.VidGrabTheme

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* refus toléré */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppGraph.tabs.attachActivity(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent { VidGrabTheme { AppRoot() } }
    }

    override fun onResume() {
        super.onResume()
        AppGraph.tabs.attachActivity(this)
        AppGraph.tabs.current.webView.onResume()
    }

    override fun onPause() {
        AppGraph.tabs.current.webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        AppGraph.tabs.detachActivity(this)   // évite la fuite de l'Activity lors des rotations
        super.onDestroy()
    }
}
