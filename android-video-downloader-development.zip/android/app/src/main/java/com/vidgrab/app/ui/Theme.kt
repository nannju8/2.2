package com.vidgrab.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Brand = Color(0xFFE53935)
val BrandDark = Color(0xFFB71C1C)
val Ink = Color(0xFF14151A)

private val Light = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE3E1),
    onPrimaryContainer = Color(0xFF410002),
    secondary = Color(0xFF3F51B5),
    background = Color(0xFFF7F7FA),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEDEEF3),
    surfaceContainer = Color(0xFFF1F2F7)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFFF6B66),
    onPrimary = Color(0xFF3B0003),
    primaryContainer = Color(0xFF5A1012),
    secondary = Color(0xFF9FA8FF),
    background = Color(0xFF0F1014),
    surface = Color(0xFF17181E),
    surfaceVariant = Color(0xFF262830),
    surfaceContainer = Color(0xFF1D1E25)
)

@Composable
fun VidGrabTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
