package com.vidgrab.app.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

data class Bookmark(val url: String, val title: String)
data class HistoryEntry(val url: String, val title: String, val host: String, val time: Long)

/** Transforme la saisie utilisateur en URL ou en recherche Google. */
fun normalizeInput(input: String): String {
    val t: String = input.trim()
    if (t.isEmpty()) return t
    if (t.startsWith("http://") || t.startsWith("https://")) return t
    val looksLikeHost: Boolean = !t.contains(' ') && (t.contains('.') || t.startsWith("localhost"))
    return if (looksLikeHost) "https://$t"
    else "https://www.google.com/search?q=" + Uri.encode(t)
}

fun hostOf(url: String): String = try {
    (Uri.parse(url).host ?: "").removePrefix("www.")
} catch (e: Exception) { "" }

class BookmarkStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)
    val items = mutableStateListOf<Bookmark>()

    init {
        val arr = JSONArray(prefs.getString("list", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            items.add(Bookmark(o.getString("url"), o.getString("title")))
        }
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("url", it.url).put("title", it.title)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun contains(url: String): Boolean = items.any { it.url == url }

    fun toggle(url: String, title: String) {
        val existing = items.firstOrNull { it.url == url }
        if (existing != null) items.remove(existing)
        else items.add(0, Bookmark(url, title.ifBlank { hostOf(url) }))
        save()
    }

    fun remove(b: Bookmark) { items.remove(b); save() }

    fun rename(b: Bookmark, newTitle: String) {
        val i = items.indexOf(b)
        if (i >= 0) { items[i] = b.copy(title = newTitle.ifBlank { b.title }); save() }
    }

    fun search(q: String): List<Bookmark> =
        items.filter { it.title.contains(q, true) || it.url.contains(q, true) }.take(3)
}

class HistoryStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)
    val entries = mutableStateListOf<HistoryEntry>()

    init {
        val arr = JSONArray(prefs.getString("list", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            entries.add(HistoryEntry(o.getString("url"), o.getString("title"), o.getString("host"), o.getLong("time")))
        }
    }

    private fun save() {
        val arr = JSONArray()
        entries.forEach {
            arr.put(JSONObject().put("url", it.url).put("title", it.title).put("host", it.host).put("time", it.time))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun record(url: String, title: String) {
        if (!url.startsWith("http")) return
        entries.removeAll { it.url == url }
        entries.add(0, HistoryEntry(url, title.ifBlank { hostOf(url) }, hostOf(url), System.currentTimeMillis()))
        while (entries.size > 200) entries.removeAt(entries.size - 1)
        save()
    }

    fun recentDomains(n: Int = 5): List<HistoryEntry> =
        entries.distinctBy { it.host }.take(n)

    fun search(q: String): List<HistoryEntry> =
        entries.filter { it.title.contains(q, true) || it.url.contains(q, true) }.take(4)

    fun clear() { entries.clear(); save() }
}

/** Code PIN du dossier privé : SHA-256(salt + pin), sel aléatoire de 16 octets. */
class VaultStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("vault", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = prefs.contains("hash")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(salt, pin))
            .apply()
    }

    fun verify(pin: String): Boolean {
        val saltStr: String = prefs.getString("salt", null) ?: return false
        val expected: String = prefs.getString("hash", null) ?: return false
        val salt = Base64.decode(saltStr, Base64.NO_WRAP)
        return MessageDigest.isEqual(hash(salt, pin).toByteArray(), expected.toByteArray())
    }

    private fun hash(salt: ByteArray, pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt)
        md.update(pin.toByteArray(Charsets.UTF_8))
        return md.digest().joinToString("") { String.format("%02x", it) }
    }
}
