package com.vidgrab.app.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException

/** Enregistrement public dans Movies/VidGrab via MediaStore (Android 10 → 15, aucune permission de stockage). */
object MediaStoreSaver {
    const val RELATIVE_PATH: String = "Movies/VidGrab"

    fun sanitize(name: String): String =
        name.replace(Regex("""[\\/:*?"<>|\r\n]+"""), " ").replace(Regex("\\s+"), " ").trim().take(80).ifBlank { "video" }

    fun save(ctx: Context, src: File, title: String, ext: String, mime: String): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "${sanitize(title)}.$ext")
            put(MediaStore.Video.Media.MIME_TYPE, mime)
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/VidGrab")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri: Uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("MediaStore insert impossible")
        try {
            resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out, 128 * 1024) } }
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        src.delete()
        return uri
    }
}
