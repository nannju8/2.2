package com.vidgrab.app

import android.app.Application
import android.content.Context
import com.vidgrab.app.data.BookmarkStore
import com.vidgrab.app.data.HistoryStore
import com.vidgrab.app.data.VaultStore
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.download.KeepAliveWorker
import com.vidgrab.app.web.TabManager

object AppGraph {
    lateinit var app: Application
    lateinit var bookmarks: BookmarkStore
    lateinit var history: HistoryStore
    lateinit var vault: VaultStore
    lateinit var tabs: TabManager

    fun init(a: Application) {
        app = a
        bookmarks = BookmarkStore(a)
        history = HistoryStore(a)
        vault = VaultStore(a)
        DownloadCenter.init(a)
        tabs = TabManager(a)
    }
}

class VidGrabApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
        KeepAliveWorker.schedule(this)
    }
}
