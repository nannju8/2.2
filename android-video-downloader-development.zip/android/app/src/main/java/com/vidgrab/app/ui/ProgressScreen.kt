package com.vidgrab.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vidgrab.app.data.formatBytes
import com.vidgrab.app.download.DlState
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.download.DownloadTask

@Composable
fun ProgressScreen() {
    val tasks = DownloadCenter.tasks
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        ScreenTitle("PROGRESSION", Modifier.padding(vertical = 16.dp))
        if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    EmptyIllustration()
                    Spacer(Modifier.height(16.dp))
                    Text("Aucun téléchargement en cours", style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(tasks.toList(), key = { it.id }) { DownloadCard(it) }
            }
        }
    }
}

/** Illustration vectorielle : nuage + flèche, en rotation 3D lente. */
@Composable
private fun EmptyIllustration() {
    val density: Float = LocalDensity.current.density
    val t = rememberInfiniteTransition(label = "empty")
    val rot by t.animateFloat(-25f, 25f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Reverse), label = "rot")
    val bob by t.animateFloat(-6f, 6f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "bob")
    val primary = MaterialTheme.colorScheme.primary
    Canvas(
        Modifier.size(170.dp).graphicsLayer {
            rotationY = rot; translationY = bob * density; cameraDistance = 14f * density
        }
    ) {
        val w = size.width; val h = size.height
        drawRoundRect(
            Brush.verticalGradient(listOf(primary.copy(alpha = 0.18f), primary.copy(alpha = 0.04f))),
            Offset(w * 0.05f, h * 0.05f), Size(w * 0.9f, h * 0.9f), CornerRadius(w * 0.25f)
        )
        drawCircle(Color(0xFFDDE1EE), w * 0.2f, Offset(w * 0.38f, h * 0.45f))
        drawCircle(Color(0xFFE9ECF6), w * 0.26f, Offset(w * 0.58f, h * 0.42f))
        drawRoundRect(Color(0xFFE9ECF6), Offset(w * 0.2f, h * 0.45f), Size(w * 0.6f, h * 0.2f), CornerRadius(w * 0.1f))
        val arrow = Path().apply {
            moveTo(w * 0.5f, h * 0.78f); lineTo(w * 0.36f, h * 0.60f); lineTo(w * 0.46f, h * 0.60f)
            lineTo(w * 0.46f, h * 0.42f); lineTo(w * 0.54f, h * 0.42f); lineTo(w * 0.54f, h * 0.60f)
            lineTo(w * 0.64f, h * 0.60f); close()
        }
        drawPath(arrow, primary)
    }
}

@Composable
private fun DownloadCard(t: DownloadTask) {
    val progress by animateFloatAsState(t.fraction, tween(400), label = "p")
    val speedMb: Double = t.speed / (1024.0 * 1024.0)
    Card(Modifier.fillMaxWidth().tilt3D(5f), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(t.video.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("${t.video.formatLabel} • ${t.video.quality}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress }, Modifier.fillMaxWidth().height(8.dp),
                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
            )
            Spacer(Modifier.height(8.dp))
            Row {
                val label: String = when (t.state) {
                    DlState.QUEUED -> "En file d'attente"
                    DlState.PAUSED -> "En pause"
                    DlState.MERGING -> "Fusion en cours…"
                    DlState.FAILED -> t.error ?: "Échec"
                    DlState.DOWNLOADING -> String.format("%.1f Mo/s", speedMb)
                }
                Text(label, style = MaterialTheme.typography.bodySmall,
                    color = if (t.state == DlState.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${formatBytes(t.downloaded)} / ${formatBytes(t.total)}", style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                when (t.state) {
                    DlState.PAUSED, DlState.FAILED ->
                        IconButton(onClick = { DownloadCenter.resume(t.id) }) { Icon(Icons.Rounded.PlayArrow, "Reprendre") }
                    DlState.DOWNLOADING, DlState.QUEUED ->
                        IconButton(onClick = { DownloadCenter.pause(t.id) }) { Icon(Icons.Rounded.Pause, "Pause") }
                    else -> {}
                }
                IconButton(onClick = { DownloadCenter.cancel(t.id) }) {
                    Icon(Icons.Rounded.Close, "Annuler", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
