package com.vidgrab.app.web

import android.net.Uri
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.VideoKind
import com.vidgrab.app.download.HlsParser
import com.vidgrab.app.net.Http
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap

/**
 * Détecte les flux vidéo, y compris camouflés (.txt/.png/.js/sans extension), en analysant
 * Content-Type puis les premiers octets (signature binaire).
 * Appelé depuis le thread IO de la WebView : aucun état Compose lu ici.
 */
class VideoSniffer(
    private val scope: CoroutineScope,
    private val onFound: (DetectedVideo) -> Unit
) {
    @Volatile var userAgent: String = ""
    @Volatile var pageUrl: String = ""
    @Volatile var pageTitle: String = ""

    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val gate = Semaphore(4)

    fun reset() = seen.clear()

    private companion object {
        val VIDEO_EXT = setOf("m3u8", "mp4", "webm", "mkv", "mov", "m4v")
        val DISGUISE_EXT = setOf("", "txt", "png", "jpg", "jpeg", "js", "php", "bin", "dat", "html5", "jsp")
        val IGNORED_EXT = setOf(
            "ts", "m4s", "css", "woff", "woff2", "ttf", "otf", "svg", "ico", "gif", "webp",
            "html", "htm", "map", "json", "xml", "vtt", "srt", "aac", "mp3", "ogg"
        )
        val SEGMENT_MARKERS = listOf("/seg", "seg-", "segment", "chunk-", ".m4s", "init.")
        val NOT_VIDEO_BRANDS = setOf("avif", "heic", "heix", "mif1", "msf1", "heim", "heis")
        const val MIN_DIRECT_SIZE: Long = 300L * 1024L
    }

    /** Appelé par shouldInterceptRequest (ou par le pont JS avec force = true). */
    fun onRequest(url: String, headers: Map<String, String>, method: String = "GET", force: Boolean = false) {
        if (!method.equals("GET", true)) return
        if (!url.startsWith("http")) return
        val uri = Uri.parse(url)
        if (AdBlock.isExcludedVideoHost(uri.host) || AdBlock.isAd(uri.host)) return

        val lower: String = url.lowercase()
        if (SEGMENT_MARKERS.any { lower.contains(it) }) return

        // Extension uniquement depuis le dernier segment du chemin (/v1.2/stream/master → "")
        val last: String = (uri.path ?: "").substringAfterLast('/', "")
        val ext: String = if (last.contains('.')) last.substringAfterLast('.').lowercase() else ""
        if (!force) {
            if (ext in IGNORED_EXT) return
            val isVideoExt: Boolean = ext in VIDEO_EXT
            if (!isVideoExt) {
                if (ext !in DISGUISE_EXT) return
                val accept: String = headers.entries.firstOrNull { it.key.equals("accept", true) }?.value ?: ""
                if (accept.startsWith("image/") || accept.contains("text/css")) return
            }
        }
        if (!seen.add(url)) return

        val sent = LinkedHashMap<String, String>(headers)
        val ua: String = userAgent
        if (ua.isNotEmpty()) sent["User-Agent"] = ua
        if (sent.keys.none { it.equals("referer", true) } && pageUrl.isNotEmpty()) sent["Referer"] = pageUrl
        val title: String = pageTitle
        val page: String = pageUrl

        scope.launch(Dispatchers.IO) {
            gate.withPermit {
                try { probeAndEmit(url, ext, sent, title, page) } catch (_: Exception) { }
            }
        }
    }

    private class Probe(val code: Int, val contentType: String, val total: Long, val bytes: ByteArray, val n: Int)

    private fun probe(url: String, headers: Map<String, String>): Probe? {
        var withRange = true
        var fullAuth = false
        val hasOrigin: Boolean = headers.keys.any { it.equals("origin", true) }
        var attempt = 0
        while (attempt < 3) {
            attempt++
            val h = LinkedHashMap<String, String>(headers)
            if (hasOrigin && !fullAuth) h.keys.removeAll { it.equals("origin", true) }
            val req = Http.request(url, h, if (withRange) "bytes=0-1023" else null)
            val resp = Http.client.newCall(req).execute()
            try {
                val code: Int = resp.code
                if (withRange && (code == 400 || code == 416 || code == 501)) { withRange = false; continue }
                if ((code == 401 || code == 403) && hasOrigin && !fullAuth) { fullAuth = true; continue }
                if (code !in 200..299) return null

                // Jamais body.string() : max 512 octets puis fermeture (anti-OOM).
                val buf = ByteArray(512)
                var n = 0
                val stream = resp.body?.byteStream()
                if (stream != null) {
                    while (n < 512) {
                        val r: Int = stream.read(buf, n, 512 - n)
                        if (r < 0) break
                        n += r
                    }
                }
                val ct: String = resp.header("Content-Type") ?: ""
                var total: Long = -1L
                val cr: String? = resp.header("Content-Range")
                if (cr != null && cr.contains('/')) {
                    total = cr.substringAfterLast('/').trim().toLongOrNull() ?: -1L
                } else if (code == 200) {
                    total = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                }
                return Probe(code, ct, total, buf, n)
            } finally {
                resp.close()
            }
        }
        return null
    }

    private fun probeAndEmit(url: String, urlExt: String, headers: Map<String, String>, title: String, page: String) {
        val p: Probe = probe(url, headers) ?: return
        val b: ByteArray = p.bytes
        val n: Int = p.n
        val ct: String = p.contentType.lowercase()

        // 1) HLS : #EXTM3U (en ignorant BOM / espaces initiaux)
        var start = 0
        while (start < n) {
            val v: Int = b[start].toInt() and 0xFF
            if (v == 0xEF || v == 0xBB || v == 0xBF || v == 0x20 || v == 0x0A || v == 0x0D) start++ else break
        }
        if (n - start >= 7 && String(b, start, 7, Charsets.ISO_8859_1) == "#EXTM3U") {
            emitHls(url, headers, title, page)
            return
        }
        // 2) Paquet MPEG-TS déguisé : octets 0 et 188 = 0x47 → segment, on rejette
        if (n > 188 && b[0].toInt() == 0x47 && b[188].toInt() == 0x47) return

        // 3) Conteneurs directs
        var ext: String? = null
        if (n >= 12 && String(b, 4, 4, Charsets.ISO_8859_1) == "ftyp") {
            val brand: String = String(b, 8, 4, Charsets.ISO_8859_1).trim().lowercase()
            if (brand in NOT_VIDEO_BRANDS) return
            ext = "mp4"
        } else if (n >= 4 && (b[0].toInt() and 0xFF) == 0x1A && (b[1].toInt() and 0xFF) == 0x45 &&
            (b[2].toInt() and 0xFF) == 0xDF && (b[3].toInt() and 0xFF) == 0xA3) {
            ext = if (ct.contains("matroska") || urlExt == "mkv") "mkv" else "webm"
        } else if (ct.startsWith("video/") && !ct.contains("mp2t") && urlExt in VIDEO_EXT && urlExt != "m3u8") {
            ext = urlExt
        }
        if (ext == null) return
        if (p.total in 1L until MIN_DIRECT_SIZE) return

        val quality: String = Regex("""(\d{3,4})p""").find(url)?.groupValues?.get(1)?.let { "${it}p" } ?: "Auto"
        onFound(
            DetectedVideo(
                url = url, title = cleanTitle(title, url), kind = VideoKind.DIRECT, ext = ext,
                quality = quality, sizeBytes = p.total, headers = headers, pageUrl = page
            )
        )
    }

    private fun fetchText(url: String, headers: Map<String, String>): String? {
        val resp = Http.client.newCall(Http.request(url, headers)).execute()
        return try {
            if (!resp.isSuccessful) null
            else {
                // Playlists : on limite à 1 Mo
                val src = resp.body?.source() ?: return null
                src.request(1024L * 1024L)
                val size: Long = minOf(src.buffer.size, 1024L * 1024L)
                src.buffer.readUtf8(size)
            }
        } finally { resp.close() }
    }

    private fun emitHls(url: String, headers: Map<String, String>, title: String, page: String) {
        val text: String = fetchText(url, headers) ?: return
        val clean: String = cleanTitle(title, url)
        if (HlsParser.isMaster(text)) {
            val variants = HlsParser.parseMaster(text, url)
            for (v in variants) {
                val dur: Double = try {
                    fetchText(v.url, headers)?.let { HlsParser.parseMedia(it, v.url).totalDurationSec } ?: 0.0
                } catch (_: Exception) { 0.0 }
                val estimated: Long = if (dur > 0.0 && v.bandwidth > 0L) ((v.bandwidth.toDouble() / 8.0) * dur).toLong() else -1L
                onFound(DetectedVideo(v.url, clean, VideoKind.HLS, "m3u8", v.label, estimated, headers, page))
            }
        } else {
            val media = HlsParser.parseMedia(text, url)
            if (media.segments.isEmpty()) return
            onFound(DetectedVideo(url, clean, VideoKind.HLS, "m3u8", "Auto", -1L, headers, page))
        }
    }

    private fun cleanTitle(pageTitle: String, url: String): String {
        var t: String = pageTitle.replace(Regex("""[\\/:*?"<>|\r\n]+"""), " ").replace(Regex("\\s+"), " ").trim()
        if (t.length > 80) t = t.take(80).trim()
        if (t.isBlank()) {
            val last: String = (Uri.parse(url).path ?: "").substringAfterLast('/', "").substringBeforeLast('.')
            t = last.ifBlank { "video_" + System.currentTimeMillis() }
        }
        return t
    }
}
