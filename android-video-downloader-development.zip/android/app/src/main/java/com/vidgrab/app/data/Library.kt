package com.vidgrab.app.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.content.FileProvider
import com.vidgrab.app.download.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class LibraryItem(
    val id: String,
    val title: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val uri: Uri,
    val isPrivate: Boolean,
    val file: File?,
    val addedAt: Long,
    val ext: String = "mp4"
)

object LibraryRepo {
    private val thumbs = LruCache<String, Bitmap>(60)

    fun privateDir(ctx: Context): File {
        val d = File(ctx.filesDir, "private").apply { mkdirs() }
        val nomedia = File(d, ".nomedia")      // invisible pour la Galerie
        if (!nomedia.exists()) nomedia.createNewFile()
        return d
    }

    // ---- « Nouveau » : vidéos jamais lues ----
    private fun watchedPrefs(ctx: Context) = ctx.getSharedPreferences("watched", Context.MODE_PRIVATE)
    fun isWatched(ctx: Context, id: String): Boolean = watchedPrefs(ctx).getBoolean(id, false)
    fun markWatched(ctx: Context, id: String) { watchedPrefs(ctx).edit().putBoolean(id, true).apply() }

    suspend fun loadPublic(ctx: Context): List<LibraryItem> = withContext(Dispatchers.IO) {
        val out = ArrayList<LibraryItem>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED
        )
        ctx.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj,
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/VidGrab%"),
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id: Long = c.getLong(0)
                out.add(
                    LibraryItem(
                        id = "m$id", title = c.getString(1).substringBeforeLast('.'), sizeBytes = c.getLong(2),
                        durationMs = c.getLong(3),
                        uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        isPrivate = false, file = null, addedAt = c.getLong(4),
                        ext = c.getString(1).substringAfterLast('.', "mp4")
                    )
                )
            }
        }
        out
    }

    suspend fun loadPrivate(ctx: Context): List<LibraryItem> = withContext(Dispatchers.IO) {
        privateDir(ctx).listFiles { f -> f.isFile && !f.name.startsWith(".") }
            ?.sortedByDescending { it.lastModified() }
            ?.map { f ->
                LibraryItem(
                    id = "p${f.name}", title = f.nameWithoutExtension, sizeBytes = f.length(),
                    durationMs = durationOf(f), uri = Uri.fromFile(f), isPrivate = true, file = f,
                    addedAt = f.lastModified() / 1000L
                )
            } ?: emptyList()
    }

    private fun durationOf(f: File): Long = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val d: Long = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        d
    } catch (e: Exception) { 0L }

    suspend fun thumbnail(ctx: Context, item: LibraryItem): Bitmap? = withContext(Dispatchers.IO) {
        thumbs.get(item.id)?.let { return@withContext it }
        val bmp: Bitmap? = try {
            if (item.isPrivate) {
                val r = MediaMetadataRetriever()
                r.setDataSource(item.file!!.absolutePath)
                val b = r.getFrameAtTime(1_000_000L)
                r.release()
                b
            } else ctx.contentResolver.loadThumbnail(item.uri, Size(480, 270), null)
        } catch (e: Exception) { null }
        if (bmp != null) thumbs.put(item.id, bmp)
        bmp
    }

    fun rename(ctx: Context, item: LibraryItem, newName: String) {
        val clean: String = MediaStoreSaver.sanitize(newName)
        if (item.isPrivate) {
            val f = item.file ?: return
            f.renameTo(File(f.parentFile, "$clean.${f.extension}"))
        } else {
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "$clean.${item.ext}")
                }
                ctx.contentResolver.update(item.uri, cv, null, null)
            } catch (_: Exception) { }
        }
    }

    fun delete(ctx: Context, item: LibraryItem) {
        if (item.isPrivate) item.file?.delete()
        else try { ctx.contentResolver.delete(item.uri, null, null) } catch (_: Exception) { }
    }

    /** Copie vers filesDir/private (+ .nomedia) puis supprime de MediaStore. */
    suspend fun moveToPrivate(ctx: Context, item: LibraryItem) = withContext(Dispatchers.IO) {
        val name: String = "${MediaStoreSaver.sanitize(item.title)}_${System.currentTimeMillis()}.mp4"
        val dest = File(privateDir(ctx), name)
        ctx.contentResolver.openInputStream(item.uri)!!.use { i -> dest.outputStream().use { i.copyTo(it, 128 * 1024) } }
        delete(ctx, item)
    }

    /** Sortie du dossier privé → Movies/VidGrab. */
    suspend fun moveToPublic(ctx: Context, item: LibraryItem) = withContext(Dispatchers.IO) {
        val f = item.file ?: return@withContext
        MediaStoreSaver.save(ctx, f, item.title, f.extension.ifBlank { "mp4" }, "video/mp4")
    }

    fun share(ctx: Context, item: LibraryItem) {
        val uri: Uri = if (item.isPrivate) {
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", item.file!!)
        } else item.uri
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "video/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
