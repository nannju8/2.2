package com.vidgrab.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.vidgrab.app.AppGraph
import com.vidgrab.app.download.DownloadCenter

@Composable
fun AppRoot() {
    val tm = AppGraph.tabs
    var page by rememberSaveable { mutableIntStateOf(0) }
    var showTabs by remember { mutableStateOf(false) }
    val activeCount: Int = DownloadCenter.tasks.size

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = page == 0, onClick = { page = 0 },
                    icon = { Icon(Icons.Rounded.Language, null) }, label = { Text("Onglet") }
                )
                NavigationBarItem(
                    selected = page == 1, onClick = { page = 1 },
                    icon = {
                        BadgedBox(badge = { if (activeCount > 0) Badge { Text("$activeCount") } }) {
                            Icon(Icons.Rounded.CloudDownload, null)
                        }
                    },
                    label = { Text("Progression") }
                )
                NavigationBarItem(
                    selected = page == 2, onClick = { page = 2 },
                    icon = { Icon(Icons.Rounded.VideoLibrary, null) }, label = { Text("Terminé") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (page) {
                0 -> BrowserHost(onShowTabs = { showTabs = true })
                1 -> ProgressScreen()
                else -> LibraryScreen()
            }
            if (showTabs) TabsOverlay(
                onDismiss = { showTabs = false },
                onPicked = { page = 0; showTabs = false }
            )
        }
    }
}

@Composable
fun TabCounter(count: Int, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(22.dp).clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.0f)),
        )
        Text("$count", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

/** Gestionnaire d'onglets visuel : cartes inclinées en 3D (rotationY + cameraDistance). */
@Composable
fun TabsOverlay(onDismiss: () -> Unit, onPicked: () -> Unit) {
    val tm = AppGraph.tabs
    val density: Float = LocalDensity.current.density
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("${tm.tabs.size} ONGLET" + if (tm.tabs.size > 1) "S" else "")
                Spacer(Modifier.weight(1f))
                FilledTonalButton(onClick = { tm.newTab(); onPicked() }) {
                    Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Nouveau")
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, "Fermer") }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(tm.tabs.toList(), key = { _, t -> t.id }) { index, tab ->
                    val left: Boolean = index % 2 == 0
                    Card(
                        modifier = Modifier
                            .graphicsLayer {
                                rotationY = if (left) 9f else -9f
                                cameraDistance = 12f * density
                            }
                            .tilt3D(8f)
                            .clickable { tm.select(index); onPicked() },
                        shape = RoundedCornerShape(20.dp),
                        elevation = CardDefaults.cardElevation(10.dp),
                        border = if (index == tm.currentIndex)
                            androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                    ) {
                        Column {
                            Row(Modifier.padding(start = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (tab.isHome) "Accueil" else tab.title.ifBlank { tab.url },
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = { tm.closeTab(index) }, Modifier.size(32.dp)) {
                                    Icon(Icons.Rounded.Close, "Fermer l'onglet", Modifier.size(18.dp))
                                }
                            }
                            Box(
                                Modifier.fillMaxWidth().height(150.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                val bmp = tab.thumbnail
                                if (bmp != null && !tab.isHome) {
                                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                                        alignment = Alignment.TopCenter)
                                } else {
                                    Icon(Icons.Rounded.Home, null, Modifier.size(40.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
