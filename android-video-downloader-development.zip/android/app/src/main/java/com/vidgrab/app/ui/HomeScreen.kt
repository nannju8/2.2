package com.vidgrab.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.AppGraph
import com.vidgrab.app.data.Bookmark
import com.vidgrab.app.data.Suggestions
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce

private data class Shortcut(val name: String, val url: String, val brush: Brush, val glyph: String)

private val shortcuts = listOf(
    Shortcut("Facebook", "https://m.facebook.com", Brush.verticalGradient(listOf(Color(0xFF3B8BFF), Color(0xFF1456C9))), "f"),
    Shortcut("Instagram", "https://www.instagram.com",
        Brush.linearGradient(listOf(Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976), Color(0xFF4F5BD5))), "I"),
    Shortcut("Vimeo", "https://vimeo.com", Brush.verticalGradient(listOf(Color(0xFF3FD0F5), Color(0xFF0E94C2))), "V"),
    Shortcut("Dailymotion", "https://www.dailymotion.com", Brush.verticalGradient(listOf(Color(0xFF3A7BFF), Color(0xFF0A1D6B))), "d"),
    Shortcut("TikTok", "https://www.tiktok.com", Brush.verticalGradient(listOf(Color(0xFF2A2A2A), Color(0xFF000000))), "T")
)

@OptIn(FlowPreview::class, ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onShowTabs: () -> Unit) {
    val tm = AppGraph.tabs
    val bookmarks = AppGraph.bookmarks
    val history = AppGraph.history
    val focus = LocalFocusManager.current

    var query by remember { mutableStateOf("") }
    var google by remember { mutableStateOf(emptyList<String>()) }
    var menu by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Bookmark?>(null) }

    LaunchedEffect(Unit) {
        snapshotFlow { query }.debounce(300).collectLatest { q ->
            google = if (q.isBlank()) emptyList() else Suggestions.google(q)
        }
    }

    fun go(s: String) { focus.clearFocus(); query = ""; google = emptyList(); tm.load(s) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // ---- Top bar ----
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TabCounter(tm.tabs.size, onShowTabs)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showHelp = true }) { Icon(Icons.Rounded.HelpOutline, "Aide") }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Rounded.Settings, "Paramètres") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Menu") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Nouvel onglet") }, onClick = { menu = false; tm.newTab() },
                        leadingIcon = { Icon(Icons.Rounded.AddBox, null) })
                    DropdownMenuItem(text = { Text("Effacer l'historique") }, onClick = { menu = false; history.clear() },
                        leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null) })
                    DropdownMenuItem(text = { Text("Comment télécharger") }, onClick = { menu = false; showHelp = true },
                        leadingIcon = { Icon(Icons.Rounded.Help, null) })
                }
            }
        }

        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
            item {
                Spacer(Modifier.height(12.dp))
                Text("VidGrab", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                // ---- Barre de recherche ----
                TextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().shadow(10.dp, RoundedCornerShape(30.dp)),
                    placeholder = { Text("Rechercher ou inscrire l'URL") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            Row {
                                IconButton(onClick = { query = ""; google = emptyList() }) {
                                    Icon(Icons.Rounded.Close, "Effacer")
                                }
                                IconButton(onClick = { go(query) }) {
                                    Icon(Icons.Rounded.ArrowForward, "Valider", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(30.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { go(query) })
                )
            }

            // ---- Suggestions : favoris, historique, Google ----
            if (query.isNotBlank()) {
                val fav = bookmarks.search(query)
                val hist = history.search(query)
                item {
                    Card(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(20.dp),
                        elevation = CardDefaults.cardElevation(6.dp)) {
                        Column {
                            fav.forEach { SuggestionRow(Icons.Rounded.Star, it.title, it.url, Color(0xFFFFB300)) { go(it.url) } }
                            hist.forEach { SuggestionRow(Icons.Rounded.History, it.title, it.url, MaterialTheme.colorScheme.secondary) { go(it.url) } }
                            google.forEach { SuggestionRow(Icons.Rounded.Search, it, null, MaterialTheme.colorScheme.primary) { go(it) } }
                        }
                    }
                }
            } else {
                // ---- Raccourcis rapides ----
                item {
                    Spacer(Modifier.height(24.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        shortcuts.forEach { s ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.tilt3D(18f).clickable { go(s.url) }) {
                                Box(Modifier.size(58.dp).shadow(10.dp, CircleShape).background(s.brush, CircleShape),
                                    contentAlignment = Alignment.Center) {
                                    Text(s.glyph, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(s.name, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }

                // ---- Mes favoris ----
                item {
                    Spacer(Modifier.height(28.dp))
                    Text("Mes favoris", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (bookmarks.items.isEmpty()) {
                        Text("Touchez l'étoile ★ dans la barre d'adresse pour ajouter un site.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        items(bookmarks.items.toList(), key = { it.url }) { b ->
                            var open by remember { mutableStateOf(false) }
                            Box {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.width(68.dp).tilt3D(16f)
                                        .combinedClickable(onClick = { go(b.url) }, onLongClick = { open = true })
                                ) {
                                    InitialBadge(b.title, colorFor(b.url))
                                    Spacer(Modifier.height(6.dp))
                                    Text(b.title, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                DropdownMenu(open, { open = false }) {
                                    DropdownMenuItem(text = { Text("Renommer") }, onClick = { open = false; renaming = b },
                                        leadingIcon = { Icon(Icons.Rounded.Edit, null) })
                                    DropdownMenuItem(text = { Text("Supprimer") }, onClick = { open = false; bookmarks.remove(b) },
                                        leadingIcon = { Icon(Icons.Rounded.Delete, null) })
                                }
                            }
                        }
                    }
                }

                // ---- Sites récents ----
                item {
                    Spacer(Modifier.height(28.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Sites web récemment utilisés", style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (history.entries.isNotEmpty()) TextButton(onClick = { history.clear() }) { Text("Effacer") }
                    }
                    Spacer(Modifier.height(6.dp))
                    val recent = history.recentDomains(5)
                    if (recent.isEmpty()) {
                        Text("Aucun site récent.", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        recent.forEach { h ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(60.dp).tilt3D(16f).clickable { go(h.url) }) {
                                InitialBadge(h.host, colorFor(h.host), 52.dp)
                                Spacer(Modifier.height(6.dp))
                                Text(h.host.substringBeforeLast('.'), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }

        // ---- Bouton d'aide pilule ----
        Button(
            onClick = { showHelp = true },
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp).tilt3D(6f),
            shape = RoundedCornerShape(30.dp)
        ) {
            Icon(Icons.Rounded.HelpOutline, null); Spacer(Modifier.width(10.dp))
            Text("Comment télécharger", fontWeight = FontWeight.Bold)
        }
    }

    if (showHelp) HowToDialog { showHelp = false }
    if (showSettings) AlertDialog(
        onDismissRequest = { showSettings = false },
        title = { Text("Paramètres") },
        text = {
            Column {
                TextButton(onClick = { history.clear() }) { Text("Effacer l'historique") }
                TextButton(onClick = { tm.clearAll(tm.current) }) { Text("Effacer cookies et cache") }
                Text("Dossier de sortie : Movies/VidGrab", style = MaterialTheme.typography.bodySmall)
                Text("Téléchargements simultanés : 2", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { showSettings = false }) { Text("OK") } }
    )
    renaming?.let { b ->
        var name by remember(b) { mutableStateOf(b.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renommer le favori") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { bookmarks.rename(b, name); renaming = null }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun SuggestionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String?, tint: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub != null) Text(sub, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Rounded.NorthWest, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun HowToDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.HelpOutline, null) },
        title = { Text("Comment télécharger") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    "1. Ouvrez un site de vidéos (Vimeo, Dailymotion, Facebook…) via la barre de recherche ou un raccourci.",
                    "2. Lancez la lecture de la vidéo.",
                    "3. Le bouton de téléchargement en bas à droite s'allume et affiche le nombre de flux détectés.",
                    "4. Touchez-le, choisissez la qualité (480p / 720p / 1080p) puis « Télécharger ».",
                    "5. Suivez l'avancement dans l'onglet Progression ; retrouvez le fichier dans Terminé."
                ).forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                Text("YouTube n'est pas pris en charge.", fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Compris") } }
    )
}
