package com.vidgrab.app.web

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.ContextWrapper
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Message
import android.webkit.*
import androidx.annotation.Keep
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vidgrab.app.AppGraph
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.normalizeInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.io.ByteArrayInputStream
import java.lang.ref.WeakReference

class TabState(val id: Int, val webView: WebView, val wrapper: MutableContextWrapper) {
    // Champs lus depuis le thread réseau de la WebView : @Volatile, pas de mutableStateOf.
    @Volatile var currentUrl: String = ""
    @Volatile var currentTitle: String = ""
    @Volatile var lastTypedAt: Long = 0L
    @Volatile var lastRealClickAt: Long = 0L

    // États Compose (thread principal).
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var desktop by mutableStateOf(false)
    var thumbnail by mutableStateOf<Bitmap?>(null)
    val videos = mutableStateListOf<DetectedVideo>()

    lateinit var sniffer: VideoSniffer

    val isHome: Boolean get() = url.isEmpty()
}

class TabManager(private val app: Context) {
    val tabs = mutableStateListOf<TabState>()
    var currentIndex by mutableIntStateOf(0)

    private var nextId = 1
    private var activityRef: WeakReference<Activity>? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val defaultUa: String by lazy {
        WebSettings.getDefaultUserAgent(app).replace("; wv", "")
    }
    private val desktopUa =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/129.0.0.0 Safari/537.36"

    val current: TabState get() = tabs[currentIndex.coerceIn(0, tabs.lastIndex)]

    init { newTab() }

    // ---- Cycle de vie Activity (évite fuites + garantit <select> natifs) ----
    fun attachActivity(activity: Activity) {
        activityRef = WeakReference(activity)
        tabs.forEach { it.wrapper.baseContext = activity }
    }

    fun detachActivity(activity: Activity) {
        if (activityRef?.get() === activity) activityRef = null
        tabs.forEach { if (it.wrapper.baseContext === activity) it.wrapper.baseContext = app }
    }

    // ---- Onglets ----
    fun newTab(): TabState {
        // JAMAIS applicationContext directement : MutableContextWrapper portant l'Activity.
        val wrapper = MutableContextWrapper(activityRef?.get() ?: app)
        val wv = WebView(wrapper)
        val tab = TabState(nextId++, wv, wrapper)
        tab.sniffer = VideoSniffer(scope) { v ->
            wv.post { if (tab.videos.none { it.url == v.url }) tab.videos.add(v) }
        }
        tab.sniffer.userAgent = defaultUa
        configure(tab)
        tabs.add(tab)
        currentIndex = tabs.lastIndex
        return tab
    }

    fun select(index: Int) {
        captureThumbnail(current)
        currentIndex = index.coerceIn(0, tabs.lastIndex)
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val t = tabs[index]
        t.webView.removeJavascriptInterface("VidGrabBridge")
        t.webView.stopLoading()
        t.webView.destroy()
        tabs.removeAt(index)
        if (tabs.isEmpty()) newTab()
        currentIndex = currentIndex.coerceIn(0, tabs.lastIndex)
        if (index < currentIndex) currentIndex--
    }

    fun goHome(tab: TabState = current) {
        captureThumbnail(tab)
        tab.webView.stopLoading()
        tab.url = ""
        tab.title = ""
        tab.currentUrl = ""
        tab.videos.clear()
        tab.sniffer.reset()
    }

    fun load(input: String, tab: TabState = current) {
        val url = normalizeInput(input)
        if (url.isEmpty()) return
        tab.lastTypedAt = System.currentTimeMillis()
        tab.url = url
        tab.currentUrl = url
        tab.sniffer.reset()
        tab.videos.clear()
        tab.webView.loadUrl(url)
    }

    fun setDesktopMode(tab: TabState, enabled: Boolean) {
        tab.desktop = enabled
        val ua: String = if (enabled) desktopUa else defaultUa
        tab.webView.settings.apply {
            userAgentString = ua
            useWideViewPort = enabled
            loadWithOverviewMode = enabled
        }
        tab.sniffer.userAgent = ua   // le sniffer doit utiliser le même UA
        tab.webView.reload()
    }

    fun clearAll(tab: TabState) {
        tab.webView.clearCache(true)
        tab.webView.clearHistory()
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        tab.videos.clear()
    }

    private fun captureThumbnail(tab: TabState) {
        try {
            val w = tab.webView
            if (w.width <= 0 || w.height <= 0) return
            val bmp = Bitmap.createBitmap(w.width / 3, w.height / 3, Bitmap.Config.RGB_565)
            val c = Canvas(bmp)
            c.scale(1f / 3f, 1f / 3f)
            w.draw(c)
            tab.thumbnail = bmp
        } catch (_: Throwable) { }
    }

    // ---- Pont JS ----
    private inner class Bridge(val tab: TabState) {
        @Keep @JavascriptInterface
        fun onLinkClick(href: String?) { tab.lastRealClickAt = System.currentTimeMillis() }

        @Keep @JavascriptInterface
        fun onVideoSrc(src: String?, title: String?) {
            if (src.isNullOrEmpty() || src.startsWith("blob:")) return
            if (!title.isNullOrBlank()) tab.sniffer.pageTitle = title
            val h = HashMap<String, String>()
            h["Referer"] = tab.currentUrl
            CookieManager.getInstance().getCookie(src)?.let { h["Cookie"] = it }
            tab.sniffer.onRequest(src, h, "GET", force = true)
        }
    }

    private fun findActivity(ctx: Context?): Activity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return c as? Activity
    }

    private fun emptyResponse() =
        WebResourceResponse("text/plain", "utf-8", 200, "OK", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(tab: TabState) {
        val wv = tab.webView
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = false
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString = defaultUa
        }
        wv.addJavascriptInterface(Bridge(tab), "VidGrabBridge")

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val host: String? = request.url.host
                if (!request.isForMainFrame && AdBlock.isAd(host)) return emptyResponse()
                if (!AdBlock.isExcludedVideoHost(host)) {
                    val headers = HashMap<String, String>(request.requestHeaders)
                    val url: String = request.url.toString()
                    if (headers.keys.none { it.equals("cookie", true) }) {
                        CookieManager.getInstance().getCookie(url)?.let { headers["Cookie"] = it }
                    }
                    tab.sniffer.onRequest(url, headers, request.method)
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Ne jamais bloquer les sous-frames (iframes de lecteurs externes).
                if (!request.isForMainFrame) return false
                val uri = request.url
                val scheme: String = uri.scheme ?: ""
                if (scheme != "http" && scheme != "https") return true   // intent://, market://…
                val host: String? = uri.host
                if (AdBlock.isAd(host)) return true

                val curHost: String? = android.net.Uri.parse(tab.currentUrl).host
                val now: Long = System.currentTimeMillis()
                val allowed: Boolean =
                    curHost.isNullOrEmpty() ||
                        AdBlock.rootDomain(host) == AdBlock.rootDomain(curHost) ||
                        AdBlock.isSearchEngine(curHost) ||
                        (now - tab.lastTypedAt) < 5000L ||
                        (now - tab.lastRealClickAt) < 2000L
                return !allowed
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                tab.currentUrl = url
                tab.url = url
                tab.loading = true
                tab.videos.clear()
                tab.sniffer.pageUrl = url
                tab.sniffer.reset()
                view.evaluateJavascript(AdBlock.INJECTED_JS, null)
            }

            override fun onPageFinished(view: WebView, url: String) {
                tab.loading = false
                tab.currentUrl = url
                tab.sniffer.pageUrl = url
                view.evaluateJavascript(AdBlock.INJECTED_JS, null)
                AppGraph.history.record(url, view.title ?: "")
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) { tab.progress = newProgress }

            override fun onReceivedTitle(view: WebView, title: String?) {
                tab.title = title ?: ""
                tab.currentTitle = title ?: ""
                tab.sniffer.pageTitle = title ?: ""
            }

            // Neutralise 100 % des pop-ups : on ne charge JAMAIS l'URL demandée.
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean =
                false

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
                showJsDialog(view, message, result, withCancel = false)

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
                showJsDialog(view, message, result, withCancel = true)

            override fun onJsBeforeUnload(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
                showJsDialog(view, message, result, withCancel = true)
        }
    }

    /** Dialogue JS sécurisé : Activity valide obligatoire, jamais deux réponses au même JsResult. */
    private fun showJsDialog(view: WebView, message: String?, result: JsResult, withCancel: Boolean): Boolean {
        val activity: Activity? = findActivity(view.context)
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            runCatching { result.cancel() }   // repli silencieux
            return true
        }
        var handled = false
        fun confirm() { if (!handled) { handled = true; runCatching { result.confirm() } } }
        fun cancel() { if (!handled) { handled = true; runCatching { result.cancel() } } }
        try {
            val b = AlertDialog.Builder(activity)
                .setMessage(message ?: "")
                .setPositiveButton(android.R.string.ok) { _, _ -> confirm() }
                .setOnCancelListener { cancel() }
            if (withCancel) b.setNegativeButton(android.R.string.cancel) { _, _ -> cancel() }
            b.show()
        } catch (e: Exception) {
            cancel()
        }
        return true
    }
}
