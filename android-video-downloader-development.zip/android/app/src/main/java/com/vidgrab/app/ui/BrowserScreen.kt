package com.vidgrab.app.ui

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.vidgrab.app.AppGraph
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.VideoKind
import com.vidgrab.app.data.formatBytes
import com.vidgrab.app.download.DownloadCenter

@Composable
fun BrowserHost(onShowTabs: () -> Unit) {
    val tm = AppGraph.tabs
    val tab = tm.current
    if (tab.isHome) HomeScreen(onShowTabs)
    else BrowserScreen(onShowTabs)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(onShowTabs: () -> Unit) {
    val tm = AppGraph.tabs
    val tab = tm.current
    val ctx = LocalContext.current
    val bookmarks = AppGraph.bookmarks
    var menu by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf(false) }
    val starred: Boolean = bookmarks.contains(tab.url)

    BackHandler {
        if (tab.webView.canGoBack()) tab.webView.goBack() else tm.goHome(tab)
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // ---- Top bar ----
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                TabCounter(tm.tabs.size, onShowTabs)
                IconButton(onClick = { tm.goHome(tab) }) { Icon(Icons.Rounded.Home, "Accueil") }

                var text by remember(tab.url) { mutableStateOf(tab.url) }
                Row(
                    Modifier.weight(1f).height(42.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(22.dp))
                        .padding(start = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = text, onValueChange = { text = it }, singleLine = true,
                        modifier = Modifier.weight(1f),
                        textStyle = TextStyle(fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { tm.load(text, tab) })
                    )
                    IconButton(onClick = { bookmarks.toggle(tab.url, tab.title) }, Modifier.size(36.dp)) {
                        Icon(
                            if (starred) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Favori",
                            tint = if (starred) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { if (tab.loading) tab.webView.stopLoading() else text = "" }, Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Close, "Arrêter / effacer", Modifier.size(20.dp))
                    }
                }

                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Menu") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Version ordinateur") },
                            leadingIcon = { Icon(Icons.Rounded.DesktopWindows, null) },
                            trailingIcon = { Checkbox(tab.desktop, null) },
                            onClick = { menu = false; tm.setDesktopMode(tab, !tab.desktop) }
                        )
                        DropdownMenuItem(text = { Text("Actualiser") }, leadingIcon = { Icon(Icons.Rounded.Refresh, null) },
                            onClick = { menu = false; tab.webView.reload() })
                        DropdownMenuItem(text = { Text("Partager le lien") }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                            onClick = {
                                menu = false
                                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, tab.url) }
                                ctx.startActivity(Intent.createChooser(i, "Partager"))
                            })
                        DropdownMenuItem(text = { Text("Ouvrir dans le navigateur externe") },
                            leadingIcon = { Icon(Icons.Rounded.OpenInBrowser, null) },
                            onClick = {
                                menu = false
                                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(tab.url))) }
                            })
                        DropdownMenuItem(text = { Text("Tout effacer") }, leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null) },
                            onClick = { menu = false; tm.clearAll(tab) })
                    }
                }
            }

            // ---- Progression fine ----
            Box(Modifier.fillMaxWidth().height(3.dp)) {
                if (tab.loading && tab.progress < 100) {
                    LinearProgressIndicator(progress = { tab.progress / 100f }, Modifier.fillMaxWidth())
                }
            }

            // ---- WebView plein écran (créée avec le contexte Activity via MutableContextWrapper) ----
            key(tab.id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
                        tab.webView.layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        tab.webView
                    }
                )
            }
        }

        // ---- FAB de détection ----
        val count: Int = tab.videos.size
        DetectFab(
            count = count,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            onClick = {
                if (count > 0) sheet = true
                else Toast.makeText(ctx, "Aucune vidéo détectée. Lancez la lecture.", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (sheet) {
        ModalBottomSheet(onDismissRequest = { sheet = false }) {
            VideoSheetContent(tab.videos.toList()) { v ->
                DownloadCenter.enqueue(v)
                Toast.makeText(ctx, "Ajouté aux téléchargements", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@Composable
fun DetectFab(count: Int, modifier: Modifier, onClick: () -> Unit) {
    val active: Boolean = count > 0
    val density: Float = LocalDensity.current.density
    val t = rememberInfiniteTransition(label = "fab")
    val pulse by t.animateFloat(1f, 1.12f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val flip by t.animateFloat(-14f, 14f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "flip")

    BadgedBox(
        modifier = modifier.graphicsLayer {
            if (active) { scaleX = pulse; scaleY = pulse; rotationY = flip; cameraDistance = 12f * density }
        },
        badge = { if (active) Badge(containerColor = Color.White, contentColor = MaterialTheme.colorScheme.primary) { Text("$count") } }
    ) {
        FloatingActionButton(
            onClick = onClick,
            shape = CircleShape,
            containerColor = if (active) MaterialTheme.colorScheme.primary else Color(0xFF8E9099),
            contentColor = Color.White,
            elevation = FloatingActionButtonDefaults.elevation(if (active) 14.dp else 4.dp)
        ) { Icon(Icons.Rounded.Download, "Télécharger") }
    }
}

@Composable
fun VideoSheetContent(videos: List<DetectedVideo>, onDownload: (DetectedVideo) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
        Text("Vidéos détectées (${videos.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(videos, key = { it.url }) { v ->
                var added by remember { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth().tilt3D(6f), shape = RoundedCornerShape(18.dp),
                    elevation = CardDefaults.cardElevation(4.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center) {
                            Icon(if (v.kind == VideoKind.HLS) Icons.Rounded.Stream else Icons.Rounded.Movie, null,
                                tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text("${v.formatLabel} • ${v.quality} • ${formatBytes(v.sizeBytes)}",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        FilledIconButton(onClick = { added = true; onDownload(v) }, enabled = !added) {
                            Icon(if (added) Icons.Rounded.Check else Icons.Rounded.Download, "Télécharger")
                        }
                    }
                }
            }
        }
    }
}
