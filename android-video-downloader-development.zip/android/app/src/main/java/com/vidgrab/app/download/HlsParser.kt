package com.vidgrab.app.download

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

data class HlsVariant(val url: String, val bandwidth: Long, val height: Int) {
    val label: String get() = if (height > 0) "${height}p" else "Auto"
}

data class HlsKey(val method: String, val uri: String?, val ivHex: String?)

data class HlsSegment(val url: String, val seq: Long, val key: HlsKey?)

data class HlsMedia(
    val segments: List<HlsSegment>,
    val initUrl: String?,
    val totalDurationSec: Double
)

object HlsParser {
    private fun resolve(base: String, ref: String): String =
        base.toHttpUrlOrNull()?.resolve(ref)?.toString() ?: ref

    private fun attr(line: String, name: String): String? {
        val m = Regex("""(?:^|[,:])$name=("([^"]*)"|[^,]*)""").find(line) ?: return null
        return m.groupValues[2].ifEmpty { m.groupValues[1].trim('"') }
    }

    fun isMaster(text: String): Boolean = text.contains("#EXT-X-STREAM-INF")

    fun parseMaster(text: String, base: String): List<HlsVariant> {
        val lines = text.lines().map { it.trim() }
        val out = ArrayList<HlsVariant>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF")) {
                val bw: Long = attr(l, "BANDWIDTH")?.toLongOrNull() ?: 0L
                val res: String? = attr(l, "RESOLUTION")
                val h: Int = res?.substringAfter('x', "")?.toIntOrNull() ?: 0
                var j = i + 1
                while (j < lines.size && (lines[j].isEmpty() || lines[j].startsWith("#"))) j++
                if (j < lines.size) out.add(HlsVariant(resolve(base, lines[j]), bw, h))
                i = j
            }
            i++
        }
        return out.sortedBy { if (it.height > 0) it.height else (it.bandwidth / 10000L).toInt() }
    }

    fun parseMedia(text: String, base: String): HlsMedia {
        var seq: Long = 0L
        var key: HlsKey? = null
        var initUrl: String? = null
        var pendingDuration = 0.0
        var total = 0.0
        val segs = ArrayList<HlsSegment>()
        for (raw in text.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                l.startsWith("#EXT-X-KEY") -> {
                    val method: String = attr(l, "METHOD") ?: "NONE"
                    key = if (method == "NONE") null
                    else HlsKey(method, attr(l, "URI")?.let { resolve(base, it) }, attr(l, "IV"))
                }
                l.startsWith("#EXT-X-MAP") -> attr(l, "URI")?.let { initUrl = resolve(base, it) }
                l.startsWith("#EXTINF:") -> {
                    pendingDuration = l.substringAfter(':').substringBefore(',').toDoubleOrNull() ?: 0.0
                }
                l.isNotEmpty() && !l.startsWith("#") -> {
                    segs.add(HlsSegment(resolve(base, l), seq, key))
                    seq += 1L
                    total += pendingDuration
                    pendingDuration = 0.0
                }
            }
        }
        return HlsMedia(segs, initUrl, total)
    }
}
