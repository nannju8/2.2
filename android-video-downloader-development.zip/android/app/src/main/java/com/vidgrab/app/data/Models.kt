package com.vidgrab.app.data

enum class VideoKind { DIRECT, HLS }

/** Une vidéo détectée par le VideoSniffer (ou remontée par le pont JS). */
data class DetectedVideo(
    val url: String,
    val title: String,
    val kind: VideoKind,
    /** mp4 / mkv / webm / m3u8 */
    val ext: String,
    /** "480p", "720p", "1080p", "Auto" … */
    val quality: String,
    /** Taille réelle (ou estimée pour HLS) en octets, -1 si inconnue. */
    val sizeBytes: Long,
    /** En-têtes exacts de la requête WebView (Referer, Origin, User-Agent, Cookie…). */
    val headers: Map<String, String>,
    val pageUrl: String
) {
    val formatLabel: String get() = if (kind == VideoKind.HLS) "HLS" else ext.uppercase()
}

fun formatBytes(bytes: Long): String {
    if (bytes < 0L) return "—"
    val kb: Double = bytes.toDouble() / 1024.0
    val mb: Double = kb / 1024.0
    val gb: Double = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.2f Go", gb)
        mb >= 1.0 -> String.format("%.1f Mo", mb)
        else -> String.format("%.0f Ko", kb)
    }
}

fun formatDuration(ms: Long): String {
    val totalSec: Long = ms / 1000L
    val h: Long = totalSec / 3600L
    val m: Long = (totalSec % 3600L) / 60L
    val s: Long = totalSec % 60L
    return if (h > 0L) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}
