package com.vidgrab.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidgrab.app.AppGraph
import com.vidgrab.app.data.LibraryItem
import com.vidgrab.app.data.LibraryRepo
import com.vidgrab.app.data.formatBytes
import com.vidgrab.app.data.formatDuration
import com.vidgrab.app.download.DownloadCenter
import com.vidgrab.app.player.PlayerActivity
import kotlinx.coroutines.launch

private enum class Sort(val label: String) { DATE("Date"), NAME("Nom"), SIZE("Taille") }

@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val vault = AppGraph.vault

    var inVault by remember { mutableStateOf(false) }
    var items by remember { mutableStateOf(emptyList<LibraryItem>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var sort by remember { mutableStateOf(Sort.DATE) }
    var sortMenu by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf<String?>(null) }   // "create" | "enter"
    var renaming by remember { mutableStateOf<LibraryItem?>(null) }
    var deleting by remember { mutableStateOf<LibraryItem?>(null) }

    LaunchedEffect(inVault, refresh, DownloadCenter.completedCounter) {
        items = if (inVault) LibraryRepo.loadPrivate(ctx) else LibraryRepo.loadPublic(ctx)
    }

    val sorted: List<LibraryItem> = when (sort) {
        Sort.DATE -> items.sortedByDescending { it.addedAt }
        Sort.NAME -> items.sortedBy { it.title.lowercase() }
        Sort.SIZE -> items.sortedByDescending { it.sizeBytes }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle(if (inVault) "PRIVÉ" else "TERMINÉ", Modifier.weight(1f))
            IconButton(onClick = {
                if (inVault) inVault = false
                else pinDialog = if (vault.hasPin()) "enter" else "create"
            }) {
                Icon(if (inVault) Icons.Rounded.LockOpen else Icons.Rounded.Lock, "Dossier verrouillé",
                    tint = if (inVault) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            }
            Box {
                IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.Sort, "Trier") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    Sort.values().forEach { s ->
                        DropdownMenuItem(
                            text = { Text("Trier par ${s.label.lowercase()}") },
                            leadingIcon = { if (sort == s) Icon(Icons.Rounded.Check, null) },
                            onClick = { sort = s; sortMenu = false }
                        )
                    }
                }
            }
        }

        if (sorted.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (inVault) "Le dossier privé est vide" else "Aucune vidéo téléchargée",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(sorted, key = { it.id }) { item ->
                    VideoCard(
                        item = item, ctx = ctx,
                        onPlay = { play(ctx, item); refresh++ },
                        onRename = { renaming = item },
                        onShare = { LibraryRepo.share(ctx, item) },
                        onMove = {
                            scope.launch {
                                if (item.isPrivate) LibraryRepo.moveToPublic(ctx, item).also { LibraryRepo.delete(ctx, item) }
                                else if (!vault.hasPin()) pinDialog = "create"
                                else LibraryRepo.moveToPrivate(ctx, item)
                                refresh++
                            }
                        },
                        onDelete = { deleting = item }
                    )
                }
            }
        }
    }

    // ---- Dialogues ----
    pinDialog?.let { mode ->
        PinDialog(
            create = mode == "create",
            onDismiss = { pinDialog = null },
            onSubmit = { pin ->
                if (mode == "create") { vault.setPin(pin); pinDialog = null; inVault = true; true }
                else if (vault.verify(pin)) { pinDialog = null; inVault = true; true }
                else false
            }
        )
    }
    renaming?.let { item ->
        var name by remember(item) { mutableStateOf(item.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renommer") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { LibraryRepo.rename(ctx, item, name); renaming = null; refresh++ }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Annuler") } }
        )
    }
    deleting?.let { item ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer la vidéo ?") },
            text = { Text(item.title) },
            confirmButton = { TextButton(onClick = { LibraryRepo.delete(ctx, item); deleting = null; refresh++ }) { Text("Supprimer") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } }
        )
    }
}

private fun play(ctx: Context, item: LibraryItem) {
    LibraryRepo.markWatched(ctx, item.id)
    ctx.startActivity(
        Intent(ctx, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URI, item.uri.toString())
            .putExtra(PlayerActivity.EXTRA_TITLE, item.title)
    )
}

@Composable
private fun PinDialog(create: Boolean, onDismiss: () -> Unit, onSubmit: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Lock, null) },
        title = { Text(if (create) "Créer un code PIN" else "Dossier privé") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    pin, { if (it.length <= 8 && it.all(Char::isDigit)) pin = it }, label = { Text("Code PIN") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                if (create) OutlinedTextField(
                    confirm, { if (it.length <= 8 && it.all(Char::isDigit)) confirm = it }, label = { Text("Confirmer") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> error = "Au moins 4 chiffres"
                    create && pin != confirm -> error = "Les codes ne correspondent pas"
                    !onSubmit(pin) -> error = "Code incorrect"
                }
            }) { Text("Valider") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun VideoCard(
    item: LibraryItem, ctx: Context,
    onPlay: () -> Unit, onRename: () -> Unit, onShare: () -> Unit, onMove: () -> Unit, onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    var bmp by remember(item.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.id) { bmp = LibraryRepo.thumbnail(ctx, item) }
    val isNew: Boolean = !LibraryRepo.isWatched(ctx, item.id)

    Card(
        Modifier.fillMaxWidth().tilt3D(5f).clickable(onClick = onPlay),
        shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(6.dp)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(140.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)).background(Color(0xFF22242C))) {
                bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    ?: Icon(Icons.Rounded.PlayCircle, null, Modifier.align(Alignment.Center), tint = Color.White.copy(alpha = 0.6f))
                if (isNew) Text(
                    "Nouveau", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                        .background(Color(0xFFE53935), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
                )
                if (item.durationMs > 0L) Text(
                    formatDuration(item.durationMs), color = Color.White, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(formatBytes(item.sizeBytes), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Actions") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Lire") }, leadingIcon = { Icon(Icons.Rounded.PlayArrow, null) },
                        onClick = { menu = false; onPlay() })
                    DropdownMenuItem(text = { Text("Renommer") }, leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                        onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Partager") }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                        onClick = { menu = false; onShare() })
                    DropdownMenuItem(
                        text = { Text(if (item.isPrivate) "Sortir du dossier privé" else "Déplacer vers le dossier privé") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                        onClick = { menu = false; onMove() })
                    DropdownMenuItem(text = { Text("Supprimer") }, leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                        onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}
