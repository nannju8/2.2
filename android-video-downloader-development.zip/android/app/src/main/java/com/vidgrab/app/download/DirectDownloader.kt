package com.vidgrab.app.download

import android.content.Context
import com.vidgrab.app.net.Http
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * File dynamique de micro-blocs (3 Mo) consommée par 6 à 8 workers : la vitesse reste
 * maximale jusqu'au dernier octet (pas de « queue » lente comme avec de gros segments fixes).
 */
object DirectDownloader {
    private const val BLOCK: Long = 3L * 1024L * 1024L
    private const val BUF: Int = 128 * 1024

    private class Info(val total: Long, val rangeOk: Boolean)

    fun mimeFor(ext: String): String = when (ext) {
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        else -> "video/mp4"
    }

    private fun probe(task: DownloadTask): Info {
        val v = task.video
        var withRange = true
        var attempt = 0
        while (attempt < 2) {
            attempt++
            val call = Http.client.newCall(Http.request(v.url, v.headers, if (withRange) "bytes=0-0" else null))
            task.calls.add(call)
            try {
                val resp = call.execute()
                try {
                    if (withRange && (resp.code == 400 || resp.code == 416 || resp.code == 501)) { withRange = false; continue }
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    if (resp.code == 206) {
                        val total: Long = resp.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1L
                        return Info(total, total > 0L)
                    }
                    val len: Long = resp.header("Content-Length")?.toLongOrNull() ?: v.sizeBytes
                    return Info(len, false)
                } finally { resp.close() }
            } finally { task.calls.remove(call) }
        }
        throw IOException("Sonde impossible")
    }

    suspend fun download(app: Context, task: DownloadTask): DownloadResult = coroutineScope {
        val dir = File(app.filesDir, "dl_tmp/${task.id}").apply { mkdirs() }
        val file = File(dir, "video.part")
        val info: Info = probe(task)
        task.total = info.total

        if (info.rangeOk && info.total > 0L) {
            val total: Long = info.total
            RandomAccessFile(file, "rw").use { if (it.length() != total) it.setLength(total) }
            val blockCount: Int = ((total + BLOCK - 1L) / BLOCK).toInt()
            val queue = ConcurrentLinkedQueue<Int>()
            var already: Long = 0L
            for (i in 0 until blockCount) {
                if (i in task.doneBlocks) {
                    already += minOf(BLOCK, total - i.toLong() * BLOCK)
                } else queue.add(i)
            }
            task.bytes.set(already)
            task.lastBytes = already
            val workers: Int = if (total < 20L * 1024L * 1024L) 6 else 8

            val jobs = (1..workers).map {
                async(Dispatchers.IO) {
                    try {
                        while (true) {
                            ensureActive()
                            val idx: Int = queue.poll() ?: break
                            fetchBlock(task, file, idx, total)
                        }
                    } catch (e: Exception) {
                        task.cancelCalls()   // coupe immédiatement les sockets des autres workers
                        throw e
                    }
                }
            }
            jobs.awaitAll()
        } else {
            // Le serveur ne supporte pas Range : flux unique.
            task.bytes.set(0L)
            task.lastBytes = 0L
            singleStream(task, file)
        }
        DownloadResult(file, task.video.ext, mimeFor(task.video.ext))
    }

    private suspend fun kotlinx.coroutines.CoroutineScope.fetchBlock(task: DownloadTask, file: File, idx: Int, total: Long) {
        val start: Long = idx.toLong() * BLOCK
        val end: Long = minOf(total - 1L, start + BLOCK - 1L)
        var attempt = 0
        while (true) {
            val counted = LongArray(1)
            try {
                val call = Http.client.newCall(Http.request(task.video.url, task.video.headers, "bytes=$start-$end"))
                task.calls.add(call)
                try {
                    call.execute().use { resp ->
                        if (resp.code != 206) throw IOException("HTTP ${resp.code}")
                        val input = BufferedInputStream(resp.body!!.byteStream(), BUF)
                        RandomAccessFile(file, "rw").use { raf ->
                            raf.seek(start)
                            val buf = ByteArray(BUF)
                            var remaining: Long = end - start + 1L
                            while (remaining > 0L) {
                                ensureActive()
                                val want: Int = minOf(buf.size.toLong(), remaining).toInt()
                                val r: Int = input.read(buf, 0, want)
                                if (r < 0) throw IOException("EOF prématuré")
                                raf.write(buf, 0, r)
                                remaining -= r.toLong()
                                counted[0] += r.toLong()
                                task.bytes.addAndGet(r.toLong())
                            }
                        }
                    }
                } finally { task.calls.remove(call) }
                task.doneBlocks.add(idx)
                return
            } catch (e: Exception) {
                task.bytes.addAndGet(-counted[0])
                if (e is CancellationException || !task.wantRunning) throw e
                attempt++
                if (attempt >= 4) throw e
                delay(500L * attempt)
            }
        }
    }

    private suspend fun kotlinx.coroutines.CoroutineScope.singleStream(task: DownloadTask, file: File) {
        val call = Http.client.newCall(Http.request(task.video.url, task.video.headers))
        task.calls.add(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                val len: Long = resp.body?.contentLength() ?: -1L
                if (len > 0L) task.total = len
                val input = BufferedInputStream(resp.body!!.byteStream(), BUF)
                file.outputStream().buffered(BUF).use { out ->
                    val buf = ByteArray(BUF)
                    while (true) {
                        ensureActive()
                        val r: Int = input.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        task.bytes.addAndGet(r.toLong())
                    }
                }
            }
        } finally { task.calls.remove(call) }
    }
}
