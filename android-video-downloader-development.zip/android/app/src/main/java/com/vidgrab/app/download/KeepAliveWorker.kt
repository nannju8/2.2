package com.vidgrab.app.download

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Toutes les 15 min : relance les téléchargements interrompus, sans jamais créer de doublon. */
class KeepAliveWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        DownloadCenter.init(applicationContext)          // idempotent
        // resume() vérifie `job.isActive` : un téléchargement déjà actif n'est jamais relancé.
        DownloadCenter.resumeInterrupted()
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<KeepAliveWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                "vidgrab_keepalive", ExistingPeriodicWorkPolicy.KEEP, req
            )
        }
    }
}
