package com.vidgrab.app.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/**
 * Effet 3D : le composant s'incline (rotationX / rotationY + cameraDistance) vers le doigt
 * pendant l'appui, puis revient en ressort. N'intercepte aucun événement (les clics fonctionnent).
 */
fun Modifier.tilt3D(maxDegrees: Float = 12f): Modifier = composed3D(maxDegrees)

@Composable
private fun rememberTilt() = remember { floatArrayOf(0f, 0f) }

private fun Modifier.composed3D(maxDegrees: Float): Modifier = androidx.compose.ui.composed {
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    val ax by animateFloatAsState(tx, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "tx")
    val ay by animateFloatAsState(ty, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "ty")
    val density: Float = LocalDensity.current.density
    this
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val ch = ev.changes.firstOrNull() ?: continue
                    if (ch.pressed && size.width > 0 && size.height > 0) {
                        val nx: Float = (ch.position.x / size.width.toFloat() - 0.5f) * 2f
                        val ny: Float = (ch.position.y / size.height.toFloat() - 0.5f) * 2f
                        ty = nx.coerceIn(-1f, 1f) * maxDegrees
                        tx = -ny.coerceIn(-1f, 1f) * maxDegrees
                    } else { tx = 0f; ty = 0f }
                }
            }
        }
        .graphicsLayer {
            rotationX = ax
            rotationY = ay
            cameraDistance = 14f * density
            val s: Float = 1f - (abs(ax) + abs(ay)) / 400f
            scaleX = s; scaleY = s
        }
}

fun colorFor(seed: String): Color {
    val hue: Float = (abs(seed.hashCode()) % 360).toFloat()
    return Color.hsv(hue, 0.55f, 0.85f)
}

/** Pastille ronde avec initiale + ombre (relief). */
@Composable
fun InitialBadge(label: String, color: Color, size: Dp = 56.dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .shadow(8.dp, CircleShape)
            .background(color, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label.take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp
        )
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 2.sp
    )
}
