package com.vidgrab.app.data

import android.net.Uri
import com.vidgrab.app.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

object Suggestions {
    /** Suggestions Google en direct ; timeout 3 s, échec silencieux hors ligne. */
    suspend fun google(query: String): List<String> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        try {
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&q=" + Uri.encode(query)
            val client = Http.client.newBuilder()
                .callTimeout(3, TimeUnit.SECONDS)
                .build()
            client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                if (!resp.isSuccessful) return@use emptyList<String>()
                val body: String = resp.body?.string() ?: return@use emptyList<String>()
                val arr = JSONArray(body)
                val list = arr.getJSONArray(1)
                (0 until minOf(list.length(), 6)).map { list.getString(it) }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
