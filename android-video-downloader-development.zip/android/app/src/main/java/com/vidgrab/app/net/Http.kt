package com.vidgrab.app.net

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** OkHttpClient singleton : le dispatcher par défaut plafonne à 5 requêtes / hôte, on monte à 16. */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dispatcher(Dispatcher().apply {
                maxRequests = 64
                maxRequestsPerHost = 16
            })
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    private val SKIPPED = setOf(
        "host", "range", "accept-encoding", "content-length", "connection",
        "if-range", "if-none-match", "if-modified-since"
    )

    /** Construit une requête GET en reprenant les en-têtes capturés (Referer, Origin, UA, Cookie…). */
    fun request(url: String, headers: Map<String, String>, range: String? = null): Request {
        val b = Request.Builder().url(url).get()
        for ((k, v) in headers) {
            if (k.lowercase() !in SKIPPED) b.header(k, v)
        }
        b.header("Accept-Encoding", "identity")
        if (range != null) b.header("Range", range)
        return b.build()
    }
}
