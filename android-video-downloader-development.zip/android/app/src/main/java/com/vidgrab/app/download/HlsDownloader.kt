package com.vidgrab.app.download

import android.content.Context
import android.net.Uri
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.vidgrab.app.net.Http
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

object HlsDownloader {
    private const val BUF: Int = 128 * 1024      // 128 Ko, jamais 512 octets
    private const val WORKERS: Int = 8

    private fun fetchText(url: String, headers: Map<String, String>, task: DownloadTask): String {
        val call = Http.client.newCall(Http.request(url, headers))
        task.calls.add(call)
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                return r.body!!.string()
            }
        } finally { task.calls.remove(call) }
    }

    private fun fetchBytes(url: String, headers: Map<String, String>, task: DownloadTask): ByteArray {
        val call = Http.client.newCall(Http.request(url, headers))
        task.calls.add(call)
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                return r.body!!.bytes()
            }
        } finally { task.calls.remove(call) }
    }

    suspend fun download(app: Context, task: DownloadTask): DownloadResult = coroutineScope {
        val dir = File(app.filesDir, "dl_tmp/${task.id}").apply { mkdirs() }
        val headers: Map<String, String> = task.video.headers

        var playlistUrl: String = task.video.url
        var text: String = fetchText(playlistUrl, headers, task)
        if (HlsParser.isMaster(text)) {
            val variants = HlsParser.parseMaster(text, playlistUrl)
            val pick = variants.firstOrNull { it.label == task.video.quality } ?: variants.lastOrNull()
                ?: throw IOException("Master HLS vide")
            playlistUrl = pick.url
            text = fetchText(playlistUrl, headers, task)
        }
        val media: HlsMedia = HlsParser.parseMedia(text, playlistUrl)
        val segs: List<HlsSegment> = media.segments
        if (segs.isEmpty()) throw IOException("Aucun segment")

        // Segment d'initialisation (fMP4)
        val initFile = File(dir, "init.bin")
        if (media.initUrl != null && !initFile.exists()) initFile.writeBytes(fetchBytes(media.initUrl, headers, task))

        // Reprise : segments déjà présents
        var already: Long = 0L
        val queue = ConcurrentLinkedQueue<Int>()
        for (i in segs.indices) {
            val f = File(dir, "seg_$i.bin")
            if (f.exists() && i in task.doneSegments) already += f.length() else queue.add(i)
        }
        task.bytes.set(already)
        task.lastBytes = already
        val keyCache = ConcurrentHashMap<String, ByteArray>()

        fun updateEstimate() {
            val done: Int = task.doneSegments.size
            if (done > 0) task.total = (task.bytes.get().toDouble() / done.toDouble() * segs.size.toDouble()).toLong()
        }
        updateEstimate()

        val jobs = (1..WORKERS).map {
            async(Dispatchers.IO) {
                try {
                    while (true) {
                        ensureActive()
                        val idx: Int = queue.poll() ?: break
                        fetchSegment(task, dir, idx, segs[idx], keyCache)
                        updateEstimate()
                    }
                } catch (e: Exception) {
                    task.cancelCalls()
                    throw e
                }
            }
        }
        jobs.awaitAll()
        task.total = task.bytes.get()

        // Fusion binaire des segments (aucun ré-encodage)
        task.state = DlState.MERGING
        val merged = File(dir, "merged.ts")
        merged.outputStream().buffered(BUF).use { out ->
            if (media.initUrl != null) initFile.inputStream().use { it.copyTo(out, BUF) }
            for (i in segs.indices) {
                ensureActive()
                File(dir, "seg_$i.bin").inputStream().use { it.copyTo(out, BUF) }
            }
        }
        for (i in segs.indices) File(dir, "seg_$i.bin").delete()

        if (media.initUrl != null) {
            // fMP4 : déjà un conteneur MP4 valide
            val mp4 = File(dir, "merged.mp4")
            merged.renameTo(mp4)
            return@coroutineScope DownloadResult(mp4, "mp4", "video/mp4")
        }

        // .ts → .mp4 via Media3 Transformer ; repli propre en .ts si le remuxing échoue
        val mp4 = File(dir, "merged.mp4")
        val ok: Boolean = remux(app, merged, mp4)
        if (ok && mp4.length() > 1024L) {
            merged.delete()
            DownloadResult(mp4, "mp4", "video/mp4")
        } else {
            mp4.delete()
            DownloadResult(merged, "ts", "video/mp2t")
        }
    }

    private suspend fun CoroutineScope.fetchSegment(
        task: DownloadTask, dir: File, idx: Int, seg: HlsSegment, keyCache: ConcurrentHashMap<String, ByteArray>
    ) {
        val part = File(dir, "seg_$idx.part")
        val bin = File(dir, "seg_$idx.bin")
        var attempt = 0
        while (true) {
            var counted: Long = 0L
            try {
                val call = Http.client.newCall(Http.request(seg.url, task.video.headers))
                task.calls.add(call)
                try {
                    call.execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                        val input = BufferedInputStream(resp.body!!.byteStream(), BUF)
                        part.outputStream().buffered(BUF).use { out ->
                            val buf = ByteArray(BUF)
                            while (true) {
                                ensureActive()
                                val r: Int = input.read(buf)
                                if (r < 0) break
                                out.write(buf, 0, r)
                                counted += r.toLong()
                                task.bytes.addAndGet(r.toLong())
                            }
                        }
                    }
                } finally { task.calls.remove(call) }

                val key: HlsKey? = seg.key
                if (key != null && key.method == "AES-128" && key.uri != null) {
                    val keyBytes: ByteArray = keyCache.getOrPut(key.uri) { fetchBytes(key.uri, task.video.headers, task) }
                    val iv: ByteArray = ivFor(key, seg.seq)
                    val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(iv))
                    CipherInputStream(BufferedInputStream(part.inputStream(), BUF), cipher).use { cin ->
                        bin.outputStream().buffered(BUF).use { cin.copyTo(it, BUF) }
                    }
                    part.delete()
                } else {
                    if (bin.exists()) bin.delete()
                    if (!part.renameTo(bin)) throw IOException("rename")
                }
                task.doneSegments.add(idx)
                return
            } catch (e: Exception) {
                task.bytes.addAndGet(-counted)
                part.delete()
                if (e is CancellationException || !task.wantRunning) throw e
                attempt++
                if (attempt >= 4) throw e
                delay(500L * attempt)
            }
        }
    }

    private fun ivFor(key: HlsKey, seq: Long): ByteArray {
        val hex: String? = key.ivHex?.removePrefix("0x")?.removePrefix("0X")
        if (!hex.isNullOrEmpty()) {
            val padded: String = hex.padStart(32, '0')
            return ByteArray(16) { i -> padded.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        }
        val iv = ByteArray(16)
        var s: Long = seq
        for (i in 15 downTo 8) { iv[i] = (s and 0xFF).toByte(); s = s shr 8 }
        return iv
    }

    /**
     * Transformer DOIT être créé avec le Looper principal et démarré sur le thread principal,
     * sinon crash depuis Dispatchers.IO.
     */
    @androidx.annotation.OptIn(UnstableApi::class)
    private suspend fun remux(app: Context, input: File, output: File): Boolean {
        val done = CompletableDeferred<Boolean>()
        var transformer: Transformer? = null
        withContext(Dispatchers.Main) {
            try {
                val t = Transformer.Builder(app)
                    .setLooper(Looper.getMainLooper())
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            done.complete(true)
                        }

                        override fun onError(
                            composition: Composition, exportResult: ExportResult, exportException: ExportException
                        ) {
                            done.complete(false)
                        }
                    })
                    .build()
                transformer = t
                val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input))).build()
                t.start(item, output.absolutePath)
            } catch (e: Exception) {
                done.complete(false)
            }
        }
        return try {
            done.await()
        } catch (e: CancellationException) {
            withContext(NonCancellable + Dispatchers.Main) { runCatching { transformer?.cancel() } }
            throw e
        }
    }
}
