package com.vidgrab.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.vidgrab.app.MainActivity
import com.vidgrab.app.data.formatBytes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** ForegroundService (dataSync) + PARTIAL_WAKE_LOCK + WifiLock HIGH_PERF + notification live. */
class DownloadService : Service() {
    companion object {
        private const val CHANNEL = "vidgrab_downloads"
        private const val NOTIF_ID = 4242

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
            } catch (e: Exception) {
                // Démarrage interdit en arrière-plan : le worker réessaiera.
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Téléchargements", NotificationManager.IMPORTANCE_LOW))
    }

    @Suppress("DEPRECATION")
    private fun ensureLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vidgrab:download")
        }
        if (wakeLock?.isHeld != true) wakeLock?.acquire(6L * 60L * 60L * 1000L)

        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            // HIGH_PERF (et non LOW_LATENCY, inactif écran éteint)
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "vidgrab:wifi")
        }
        if (wifiLock?.isHeld != true) wifiLock?.acquire()
    }

    private fun releaseLocks() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
    }

    private fun buildNotification(): Notification {
        val active = DownloadCenter.tasks.filter { it.state == DlState.DOWNLOADING || it.state == DlState.MERGING }
        val queued: Int = DownloadCenter.tasks.count { it.state == DlState.QUEUED }
        val speed: Double = active.sumOf { it.speed }
        val done: Long = active.sumOf { it.downloaded }
        val total: Long = active.sumOf { if (it.total > 0L) it.total else 0L }
        val pct: Int = if (total > 0L) ((done.toDouble() / total.toDouble()) * 100.0).toInt().coerceIn(0, 100) else 0
        val speedMb: Double = speed / (1024.0 * 1024.0)
        val text: String = String.format("%d%% • %.1f Mo/s • %s / %s", pct, speedMb, formatBytes(done), formatBytes(total))
        val pi = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("VidGrab — ${active.size} en cours" + if (queued > 0) " (+$queued en attente)" else "")
            .setContentText(text)
            .setProgress(100, pct, total <= 0L)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        ensureLocks()
        if (loop?.isActive != true) {
            loop = scope.launch {
                var idle = 0
                val nm = getSystemService(NotificationManager::class.java)
                while (true) {
                    delay(1000L)
                    ensureLocks()                         // vérifie que les locks sont toujours tenus
                    if (DownloadCenter.hasActive()) {
                        idle = 0
                        nm.notify(NOTIF_ID, buildNotification())
                    } else if (++idle >= 3) {
                        stopSelf()
                        break
                    }
                }
            }
        }
        return START_STICKY
    }

    // Android 14
    override fun onTimeout(startId: Int) {
        DownloadCenter.pauseAll()
        stopSelf()
    }

    // Android 15 : limite de 6 h pour dataSync
    override fun onTimeout(startId: Int, fgsType: Int) {
        DownloadCenter.pauseAll()
        stopSelf()
    }

    override fun onDestroy() {
        loop?.cancel()
        scope.cancel()
        releaseLocks()
        super.onDestroy()
    }
}
