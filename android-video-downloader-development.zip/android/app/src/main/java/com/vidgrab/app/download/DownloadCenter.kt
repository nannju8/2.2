package com.vidgrab.app.download

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vidgrab.app.data.DetectedVideo
import com.vidgrab.app.data.VideoKind
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Call
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

enum class DlState { QUEUED, DOWNLOADING, PAUSED, MERGING, FAILED }

class DownloadResult(val file: File, val ext: String, val mime: String)

class DownloadTask(val id: String, val video: DetectedVideo) {
    var state by mutableStateOf(DlState.QUEUED)
    var downloaded by mutableLongStateOf(0L)
    var total by mutableLongStateOf(-1L)
    var speed by mutableDoubleStateOf(0.0)      // octets / s
    var error by mutableStateOf<String?>(null)

    @Volatile var wantRunning: Boolean = true
    @Volatile var job: Job? = null

    /** Compteur « live » mis à jour par les workers ; recopié dans `downloaded` par le ticker. */
    val bytes = AtomicLong(0L)
    val calls: MutableSet<Call> = ConcurrentHashMap.newKeySet()
    val doneBlocks: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    val doneSegments: MutableSet<Int> = ConcurrentHashMap.newKeySet()

    internal var lastBytes: Long = 0L

    val fraction: Float
        get() = if (total > 0L) (downloaded.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f) else 0f

    fun cancelCalls() { calls.toList().forEach { runCatching { it.cancel() } } }
}

object DownloadCenter {
    /** 2 vidéos maximum en parallèle, les suivantes attendent en file. */
    const val MAX_PARALLEL: Int = 2

    val tasks = mutableStateListOf<DownloadTask>()
    /** Incrémenté à chaque téléchargement terminé : la bibliothèque se rafraîchit. */
    var completedCounter by mutableIntStateOf(0)

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private var tickerJob: Job? = null

    fun init(ctx: Context) {
        synchronized(lock) {
            if (::app.isInitialized) return
            app = ctx.applicationContext
        }
        restore()
        startTicker()
        if (tasks.any { it.state == DlState.QUEUED }) {
            DownloadService.start(app)
            schedule()
        }
    }

    // ---- API publique ----
    fun enqueue(video: DetectedVideo): DownloadTask {
        val existing = tasks.firstOrNull { it.video.url == video.url }
        if (existing != null) return existing
        val t = DownloadTask(UUID.randomUUID().toString(), video)
        tasks.add(t)
        persist()
        DownloadService.start(app)
        schedule()
        return t
    }

    fun isActive(id: String): Boolean = tasks.firstOrNull { it.id == id }?.job?.isActive == true

    fun hasActive(): Boolean = tasks.any {
        it.state == DlState.DOWNLOADING || it.state == DlState.QUEUED || it.state == DlState.MERGING
    }

    fun pause(id: String) {
        val t = tasks.firstOrNull { it.id == id } ?: return
        t.wantRunning = false
        t.state = DlState.PAUSED
        t.speed = 0.0
        t.job?.cancel()
        t.cancelCalls()
        persist()
        schedule()
    }

    fun resume(id: String) {
        val t = tasks.firstOrNull { it.id == id } ?: return
        if (t.job?.isActive == true) return     // idempotent : jamais de doublon
        t.wantRunning = true
        t.error = null
        t.state = DlState.QUEUED
        persist()
        DownloadService.start(app)
        schedule()
    }

    fun cancel(id: String) {
        val t = tasks.firstOrNull { it.id == id } ?: return
        t.wantRunning = false
        t.job?.cancel()
        t.cancelCalls()
        tasks.remove(t)
        scope.launch { File(app.filesDir, "dl_tmp/${t.id}").deleteRecursively() }
        persist()
        schedule()
    }

    fun pauseAll() {
        tasks.toList().forEach { if (it.state != DlState.PAUSED && it.state != DlState.FAILED) pause(it.id) }
    }

    /** Appelé par le worker périodique : relance uniquement ce qui voulait tourner et n'a plus de job. */
    fun resumeInterrupted() {
        tasks.toList().forEach {
            if (it.wantRunning && it.state != DlState.FAILED && it.job?.isActive != true) resume(it.id)
        }
    }

    // ---- Ordonnanceur ----
    private fun schedule() {
        synchronized(lock) {
            var running: Int = tasks.count { it.job?.isActive == true }
            for (t in tasks.toList()) {
                if (running >= MAX_PARALLEL) break
                if (t.state == DlState.QUEUED && t.wantRunning && t.job?.isActive != true) {
                    launchTask(t)
                    running++
                }
            }
        }
    }

    private fun launchTask(t: DownloadTask) {
        t.state = DlState.DOWNLOADING
        val j = scope.launch(start = CoroutineStart.LAZY) {
            try {
                val res: DownloadResult = when (t.video.kind) {
                    VideoKind.DIRECT -> DirectDownloader.download(app, t)
                    VideoKind.HLS -> HlsDownloader.download(app, t)
                }
                t.state = DlState.MERGING
                MediaStoreSaver.save(app, res.file, t.video.title, res.ext, res.mime)
                File(app.filesDir, "dl_tmp/${t.id}").deleteRecursively()
                tasks.remove(t)
                completedCounter++
                persist()
            } catch (e: Exception) {
                if (t.wantRunning && t.state != DlState.PAUSED) {
                    t.state = DlState.FAILED
                    t.error = e.message ?: "Erreur réseau"
                    t.speed = 0.0
                    persist()
                }
            } finally {
                schedule()
            }
        }
        t.job = j
        j.start()
    }

    // ---- Vitesse en temps réel ----
    private fun startTicker() {
        if (tickerJob != null) return
        tickerJob = scope.launch {
            var last: Long = System.nanoTime()
            while (true) {
                delay(500L)
                val now: Long = System.nanoTime()
                val dt: Double = (now - last).toDouble() / 1_000_000_000.0
                last = now
                for (t in tasks.toList()) {
                    if (t.state == DlState.DOWNLOADING) {
                        val cur: Long = t.bytes.get()
                        val delta: Long = cur - t.lastBytes
                        val inst: Double = if (dt > 0.0) delta.toDouble() / dt else 0.0
                        t.speed = if (t.speed == 0.0) inst else (t.speed * 0.6 + inst * 0.4)
                        t.lastBytes = cur
                        t.downloaded = cur
                    }
                }
            }
        }
    }

    // ---- Persistance (reprise après coupure / WorkManager) ----
    private fun persist() {
        val arr = JSONArray()
        tasks.toList().forEach { t ->
            val v = t.video
            arr.put(
                JSONObject()
                    .put("id", t.id).put("url", v.url).put("title", v.title).put("kind", v.kind.name)
                    .put("ext", v.ext).put("quality", v.quality).put("size", v.sizeBytes).put("page", v.pageUrl)
                    .put("want", t.wantRunning)
                    .put("headers", JSONObject(v.headers as Map<*, *>))
            )
        }
        app.getSharedPreferences("downloads", Context.MODE_PRIVATE).edit().putString("tasks", arr.toString()).apply()
    }

    private fun restore() {
        val s: String = app.getSharedPreferences("downloads", Context.MODE_PRIVATE).getString("tasks", "[]") ?: "[]"
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val h = HashMap<String, String>()
            val ho = o.getJSONObject("headers")
            ho.keys().forEach { k -> h[k] = ho.getString(k) }
            val v = DetectedVideo(
                o.getString("url"), o.getString("title"), VideoKind.valueOf(o.getString("kind")),
                o.getString("ext"), o.getString("quality"), o.getLong("size"), h, o.getString("page")
            )
            val t = DownloadTask(o.getString("id"), v)
            t.wantRunning = o.getBoolean("want")
            t.state = if (t.wantRunning) DlState.QUEUED else DlState.PAUSED
            tasks.add(t)
        }
    }
}
