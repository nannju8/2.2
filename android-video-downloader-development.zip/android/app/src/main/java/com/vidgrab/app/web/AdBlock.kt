package com.vidgrab.app.web

/**
 * Filtre publicitaire. IMPORTANT : jamais "ad" / "ads" comme mot-clé générique
 * (faux positifs : uqload, mp4upload…). Uniquement des noms complets de régies.
 */
object AdBlock {
    private val AD_KEYWORDS = listOf(
        "doubleclick", "popads", "propellerads", "exoclick", "adsterra", "tsyndicate",
        "realsrv", "adnxs", "taboola", "outbrain", "googlesyndication", "popcash",
        "clickadu", "juicyads", "trafficjunky", "hilltopads", "onclickads", "adcash",
        "revcontent", "bidvertiser", "adskeeper", "mgid.com", "pushwoosh", "richpush",
        "monetag", "profitablegatecpm", "highperformanceformat", "acscdn", "popunder"
    )

    private val EXCLUDED_VIDEO_HOSTS = listOf(
        "youtube.com", "googlevideo.com", "youtu.be", "youtube-nocookie.com"
    )

    private val SEARCH_ENGINES = listOf(
        "google.", "bing.com", "duckduckgo.com", "yahoo.com", "qwant.com", "ecosia.org", "startpage.com"
    )

    private val SECOND_LEVEL = setOf("co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go")

    fun isAd(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        val h: String = host.lowercase()
        return AD_KEYWORDS.any { h.contains(it) }
    }

    fun isExcludedVideoHost(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        val h: String = host.lowercase()
        return EXCLUDED_VIDEO_HOSTS.any { h == it || h.endsWith(".$it") }
    }

    fun isSearchEngine(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        val h: String = host.lowercase()
        return SEARCH_ENGINES.any { h.contains(it) }
    }

    /** Domaine racine avec gestion des suffixes .co.uk, .com.br, … */
    fun rootDomain(host: String?): String {
        if (host.isNullOrEmpty()) return ""
        val parts: List<String> = host.lowercase().removePrefix("www.").split('.')
        if (parts.size <= 2) return parts.joinToString(".")
        val tld: String = parts.last()
        val sld: String = parts[parts.size - 2]
        return if (tld.length == 2 && sld in SECOND_LEVEL) parts.takeLast(3).joinToString(".")
        else parts.takeLast(2).joinToString(".")
    }

    /** Script injecté : neutralise les calques invisibles, relaie clics réels et <video>. */
    const val INJECTED_JS: String = """
(function(){
  if (window.__vgInit) return; window.__vgInit = true;
  function kill(){ try {
    var w = innerWidth, h = innerHeight;
    document.querySelectorAll('div,a,span,section').forEach(function(e){
      var s = getComputedStyle(e);
      if ((s.position === 'fixed' || s.position === 'absolute') && parseInt(s.zIndex) >= 1000) {
        var r = e.getBoundingClientRect();
        if (r.width >= w*0.5 && r.height >= h*0.5 && !e.querySelector('video,iframe,input,button')
            && (e.innerText || '').trim().length < 3) {
          var bg = s.backgroundColor;
          var clear = bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent' || parseFloat(s.opacity) < 0.05;
          if (clear) {
            e.style.setProperty('pointer-events','none','important');
            e.style.setProperty('display','none','important');
          }
        }
      }
    });
  } catch(x){} }
  setInterval(kill, 1500); kill();
  document.addEventListener('click', function(ev){
    if (!ev.isTrusted) return;
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
    if (a && a.offsetWidth > 0 && a.offsetHeight > 0) { VidGrabBridge.onLinkClick(a.href); }
  }, true);
  function rep(v){ try {
    var s = v.currentSrc;
    if (s && s.indexOf('blob:') !== 0 && s.indexOf('data:') !== 0) VidGrabBridge.onVideoSrc(s, document.title || '');
  } catch(e){} }
  ['loadedmetadata','play'].forEach(function(n){
    document.addEventListener(n, function(e){ if (e.target && e.target.tagName === 'VIDEO') rep(e.target); }, true);
  });
  document.querySelectorAll('video').forEach(function(v){ if (v.currentSrc) rep(v); });
})();
"""
}
