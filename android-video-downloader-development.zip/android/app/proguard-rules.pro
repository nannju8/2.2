-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class androidx.annotation.Keep
-keep @androidx.annotation.Keep class * { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
