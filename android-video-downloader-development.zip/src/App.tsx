import { useState } from 'react'
import { Hero3D } from './components/Hero3D'
import { Icon } from './components/Icon'

const FEATURES = [
  { icon: 'globe', title: 'Navigateur intégré', text: 'Recherche intelligente : favoris, historique et suggestions Google en direct (debounce 300 ms, échec silencieux hors ligne).' },
  { icon: 'shield', title: 'Bouclier anti-pub', text: 'Pop-ups neutralisés (onCreateWindow → false), régies bloquées, calques invisibles supprimés, navigation filtrée par domaine racine.' },
  { icon: 'search', title: 'VideoSniffer', text: 'Détection par signature binaire (#EXTM3U, ftyp, EBML) même sous .txt / .png / .js, avec Referer, Origin et cookies exacts.' },
  { icon: 'bolt', title: 'Moteur haute vitesse', text: 'Micro-blocs de 3 Mo sur 8 workers Range, HLS parallèle (AES-128), fusion Media3 Transformer vers .mp4. 2 téléchargements max.' },
  { icon: 'lock', title: 'Dossier privé', text: 'PIN haché SHA-256 salé, vidéos dans filesDir avec .nomedia : invisibles dans la Galerie système.' },
  { icon: 'library', title: 'Lecteur Media3', text: 'ExoPlayer plein écran immersif, ±10 s, content:// MediaStore et fichiers privés, cycle de vie propre.' },
]

const TREE = `android/
├─ settings.gradle.kts · build.gradle.kts · gradle.properties
├─ app/build.gradle.kts            Kotlin 2.0.20 · Compose BOM 2024.09.03
└─ app/src/main/
   ├─ AndroidManifest.xml          dataSync · POST_NOTIFICATIONS · cleartext
   └─ java/com/vidgrab/app/
      ├─ MainActivity.kt · VidGrabApp.kt
      ├─ web/       TabManager · VideoSniffer · AdBlock
      ├─ download/  DownloadCenter · DirectDownloader · HlsDownloader
      │             HlsParser · DownloadService · KeepAliveWorker
      │             MediaStoreSaver
      ├─ data/      Stores · Library · Suggestions · Models
      ├─ player/    PlayerActivity
      └─ ui/        AppRoot · HomeScreen · BrowserScreen
                    ProgressScreen · LibraryScreen · Theme · Common`

const RULES = [
  'MutableContextWrapper + attachActivity / detachActivity (menus <select> natifs)',
  'Dialogues JS : Activity valide + garde « handled », jamais de double réponse',
  'shouldOverrideUrlLoading : sous-frames jamais bloqués, schémas intent:// et market:// refusés',
  'Aucun mot-clé « ad » / « ads » générique (uqload, mp4upload préservés)',
  'Sonde OkHttp : Range 0-1023, retries 400/416/501 et 401/403, 512 octets max (anti-OOM)',
  'Rejet des segments MPEG-TS déguisés (0x47 aux octets 0 et 188)',
  'OkHttp : Dispatcher 64 / 16 par hôte, ConnectionPool(16, 5 min), Calls annulables',
  'WifiLock HIGH_PERF + PARTIAL_WAKE_LOCK revérifiés dans la boucle du service',
  'Transformer sur Looper principal, repli propre en .ts',
  'Android 15 : onTimeout(startId, fgsType) → pauseAll() + stopSelf()',
  'WorkManager 15 min idempotent : aucun téléchargement en double',
]

export default function App() {
  const [tilt, setTilt] = useState<number | null>(null)

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#07080c]">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(229,57,53,0.18),transparent_60%)]" />

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2.5 text-lg font-black tracking-tight">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e53935] shadow-lg shadow-red-600/40"><Icon name="download" size={20} /></span>
          VidGrab
        </div>
        <nav className="hidden gap-6 text-sm text-white/70 sm:flex">
          <a href="#proto" className="hover:text-white">Prototype</a>
          <a href="#features" className="hover:text-white">Fonctions</a>
          <a href="#android" className="hover:text-white">Projet Android</a>
        </nav>
      </header>

      {/* HERO */}
      <section id="proto" className="relative z-10 mx-auto grid max-w-6xl items-center gap-6 px-6 pb-16 pt-4 lg:grid-cols-2">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-white/80 ring-1 ring-white/15">
            <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" /> Kotlin · Jetpack Compose · Material 3
          </span>
          <h1 className="mt-5 text-5xl font-black leading-[1.05] tracking-tight sm:text-6xl">
            Détectez.<br />
            <span className="bg-gradient-to-r from-[#ff6b66] to-[#e53935] bg-clip-text text-transparent">Téléchargez.</span><br />
            Gardez.
          </h1>
          <p className="mt-5 max-w-md text-base leading-relaxed text-white/70">
            VidGrab est un navigateur Android natif qui repère les vidéos d'une page, même camouflées, et les télécharge à pleine vitesse en arrière-plan.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <a href="#proto" className="rounded-full bg-[#e53935] px-6 py-3 text-sm font-bold shadow-lg shadow-red-600/40 transition hover:scale-105">Essayer le prototype →</a>
            <a href="#android" className="rounded-full bg-white/10 px-6 py-3 text-sm font-bold ring-1 ring-white/20 transition hover:bg-white/20">Voir le code Android</a>
          </div>
          <div className="mt-8 max-w-md rounded-2xl bg-white/5 p-4 text-xs leading-relaxed text-white/70 ring-1 ring-white/10">
            <b className="text-white">Essayez dans le téléphone :</b> ouvrez Vimeo, lancez la lecture de la vidéo, touchez le bouton rouge qui s'allume, téléchargez plusieurs qualités (2 en parallèle, les autres en file), puis allez dans « Terminé » et testez le dossier privé avec un PIN.
          </div>
        </div>
        <Hero3D />
      </section>

      {/* FEATURES */}
      <section id="features" className="relative z-10 mx-auto max-w-6xl px-6 py-16">
        <h2 className="text-3xl font-black tracking-tight">Tout le cahier des charges, en natif</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3" style={{ perspective: 1000 }}>
          {FEATURES.map((f, i) => (
            <div
              key={f.title}
              onPointerEnter={() => setTilt(i)}
              onPointerLeave={() => setTilt(null)}
              className="rounded-3xl bg-gradient-to-b from-white/10 to-white/[0.03] p-6 ring-1 ring-white/10 transition-all duration-300"
              style={{
                transform: tilt === i ? 'rotateX(6deg) rotateY(-6deg) translateZ(20px)' : 'none',
                boxShadow: tilt === i ? '0 30px 60px -20px rgba(229,57,53,0.45)' : 'none',
              }}
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#e53935]/90 shadow-lg shadow-red-700/40"><Icon name={f.icon} size={22} /></span>
              <h3 className="mt-4 text-lg font-bold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/65">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ANDROID */}
      <section id="android" className="relative z-10 mx-auto max-w-6xl px-6 py-16">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500"><Icon name="code" size={22} /></span>
          <h2 className="text-3xl font-black tracking-tight">Le projet Android Kotlin</h2>
        </div>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/70">
          Les sources complètes sont dans le dossier <code className="rounded bg-white/10 px-1.5 py-0.5">android/</code> du projet. Ouvrez-le avec Android Studio (Koala ou plus récent, JDK 17) : il générera le wrapper Gradle 8.9 et synchronisera les dépendances.
        </p>
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <pre className="overflow-x-auto rounded-3xl bg-black/50 p-6 text-[12.5px] leading-relaxed text-emerald-200/90 ring-1 ring-white/10">{TREE}</pre>
          <div className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/10">
            <h3 className="mb-3 font-bold">Règles anti-bugs implémentées</h3>
            <ul className="space-y-2.5 text-[13px] text-white/75">
              {RULES.map((r) => (
                <li key={r} className="flex gap-2.5">
                  <span className="mt-0.5 text-emerald-400"><Icon name="check" size={16} /></span>
                  {r}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <p className="mt-6 rounded-2xl bg-amber-400/10 p-4 text-xs leading-relaxed text-amber-200 ring-1 ring-amber-300/20">
          Transparence : mon environnement ne dispose ni du SDK Android ni de Gradle, je n'ai donc pas pu compiler l'APK. Le code Kotlin est écrit avec soin, mais une première synchronisation Gradle pourra demander de petits ajustements. Le prototype ci-dessus, lui, est entièrement fonctionnel dans le navigateur, avec des données simulées (détection vidéo, suggestions, vitesses).
        </p>
      </section>

      <footer className="relative z-10 border-t border-white/10 py-8 text-center text-xs text-white/40">
        VidGrab · com.vidgrab.app · minSdk 29 · targetSdk 35
      </footer>
    </div>
  )
}
