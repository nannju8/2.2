import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import { Icon } from './Icon'
import { cn } from '../utils/cn'

/* ------------------------------------------------------------------ */
/* Types & données                                                     */
/* ------------------------------------------------------------------ */
type Video = { id: string; title: string; kind: 'MP4' | 'HLS'; quality: string; sizeMB: number }
type Dl = Video & { doneMB: number; speed: number; state: 'queued' | 'downloading' | 'paused' }
type Lib = { id: string; title: string; sizeMB: number; duration: string; isNew: boolean; hue: number; priv: boolean }
type Bookmark = { url: string; title: string }

const SHORTCUTS = [
  { name: 'Facebook', url: 'facebook.com', glyph: 'f', bg: 'linear-gradient(160deg,#3b8bff,#1456c9)' },
  { name: 'Instagram', url: 'instagram.com', glyph: 'I', bg: 'linear-gradient(45deg,#feda75,#fa7e1e,#d62976,#4f5bd5)' },
  { name: 'Vimeo', url: 'vimeo.com', glyph: 'V', bg: 'linear-gradient(160deg,#3fd0f5,#0e94c2)' },
  { name: 'Dailymotion', url: 'dailymotion.com', glyph: 'd', bg: 'linear-gradient(160deg,#3a7bff,#0a1d6b)' },
  { name: 'TikTok', url: 'tiktok.com', glyph: 'T', bg: 'linear-gradient(160deg,#2a2a2a,#000)' },
]

const DETECTED: Video[] = [
  { id: 'h1080', title: 'Aurora — Time-lapse', kind: 'HLS', quality: '1080p', sizeMB: 214.6 },
  { id: 'h720', title: 'Aurora — Time-lapse', kind: 'HLS', quality: '720p', sizeMB: 118.2 },
  { id: 'h480', title: 'Aurora — Time-lapse', kind: 'HLS', quality: '480p', sizeMB: 64.9 },
  { id: 'm720', title: 'Aurora — Time-lapse', kind: 'MP4', quality: '720p', sizeMB: 96.4 },
]

const INITIAL_LIB: Lib[] = [
  { id: 'l1', title: 'Big Buck Bunny — court métrage complet en haute définition', sizeMB: 152.3, duration: '09:56', isNew: true, hue: 140, priv: false },
  { id: 'l2', title: 'Conférence Android 15 : les nouveautés pour les développeurs', sizeMB: 410.8, duration: '37:39', isNew: true, hue: 220, priv: false },
  { id: 'l3', title: 'Vacances en Islande (drone)', sizeMB: 88.1, duration: '04:12', isNew: false, hue: 28, priv: false },
]

const colorFor = (s: string) => {
  let h = 0
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360
  return `hsl(${h} 55% 55%)`
}

const fmtMB = (mb: number) => (mb >= 1024 ? `${(mb / 1024).toFixed(2)} Go` : `${mb.toFixed(1)} Mo`)

async function sha256(salt: string, pin: string) {
  const data = new TextEncoder().encode(salt + pin)
  const buf = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

function hostOf(input: string) {
  return input
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .split('/')[0]
}

/* ------------------------------------------------------------------ */
/* Effet 3D : inclinaison au doigt / curseur                            */
/* ------------------------------------------------------------------ */
function Tilt({
  children,
  className,
  max = 10,
  onClick,
  style,
}: {
  children: ReactNode
  className?: string
  max?: number
  onClick?: () => void
  style?: CSSProperties
}) {
  const [t, setT] = useState({ x: 0, y: 0 })
  return (
    <div
      className={cn('cursor-pointer select-none', className)}
      onClick={onClick}
      onPointerMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect()
        const nx = ((e.clientX - r.left) / r.width - 0.5) * 2
        const ny = ((e.clientY - r.top) / r.height - 0.5) * 2
        setT({ x: -ny * max, y: nx * max })
      }}
      onPointerLeave={() => setT({ x: 0, y: 0 })}
      style={{
        ...style,
        transform: `perspective(520px) rotateX(${t.x}deg) rotateY(${t.y}deg) scale(${t.x || t.y ? 1.03 : 1})`,
        transition: t.x || t.y ? 'transform 0.08s' : 'transform 0.35s cubic-bezier(.3,1.6,.5,1)',
      }}
    >
      {children}
    </div>
  )
}

function Initial({ label, color, size = 52 }: { label: string; color: string; size?: number }) {
  return (
    <div
      className="flex items-center justify-center rounded-full font-bold text-white shadow-lg shadow-black/25"
      style={{ width: size, height: size, background: color, fontSize: size * 0.42 }}
    >
      {label.slice(0, 1).toUpperCase()}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Application                                                          */
/* ------------------------------------------------------------------ */
export function PhoneApp() {
  const [tab, setTab] = useState<0 | 1 | 2>(0)
  const [page, setPage] = useState<'home' | 'web'>('home')
  const [url, setUrl] = useState('')
  const [addr, setAddr] = useState('')
  const [progress, setProgress] = useState(100)
  const [desktop, setDesktop] = useState(false)
  const [tabsOpen, setTabsOpen] = useState(false)
  const [tabCount, setTabCount] = useState(1)

  const [query, setQuery] = useState('')
  const [google, setGoogle] = useState<string[]>([])
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([
    { url: 'vimeo.com', title: 'Vimeo' },
    { url: 'dailymotion.com', title: 'Dailymotion' },
  ])
  const [history, setHistory] = useState<string[]>(['vimeo.com', 'dailymotion.com', 'tiktok.com'])
  const [bmMenu, setBmMenu] = useState<string | null>(null)

  const [helpOpen, setHelpOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [homeMenu, setHomeMenu] = useState(false)
  const [sheetOpen, setSheetOpen] = useState(false)

  const [playing, setPlaying] = useState(false)
  const [videos, setVideos] = useState<Video[]>([])
  const [dls, setDls] = useState<Dl[]>([])
  const dlsRef = useRef<Dl[]>([])
  const [lib, setLib] = useState<Lib[]>(INITIAL_LIB)

  const [inVault, setInVault] = useState(false)
  const [sortBy, setSortBy] = useState<'date' | 'name' | 'size'>('date')
  const [sortMenu, setSortMenu] = useState(false)
  const [itemMenu, setItemMenu] = useState<string | null>(null)
  const [pinMode, setPinMode] = useState<null | 'create' | 'enter'>(null)
  const [pin, setPin] = useState('')
  const [pin2, setPin2] = useState('')
  const [pinErr, setPinErr] = useState('')
  const [renaming, setRenaming] = useState<Lib | null>(null)
  const [renameVal, setRenameVal] = useState('')
  const [player, setPlayer] = useState<Lib | null>(null)
  const [toast, setToast] = useState('')

  const say = useCallback((m: string) => {
    setToast(m)
    window.setTimeout(() => setToast(''), 1800)
  }, [])

  /* ---- suggestions Google simulées, debounce 300 ms ---- */
  useEffect(() => {
    if (!query.trim()) {
      setGoogle([])
      return
    }
    const id = window.setTimeout(() => {
      const q = query.trim()
      setGoogle([q + ' streaming', q + ' vidéo 1080p', q + ' en français', q + ' télécharger'])
    }, 300)
    return () => window.clearTimeout(id)
  }, [query])

  /* ---- navigation ---- */
  const loadTimer = useRef<number | undefined>(undefined)
  const startLoading = useCallback(() => {
    window.clearInterval(loadTimer.current)
    setProgress(4)
    loadTimer.current = window.setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          window.clearInterval(loadTimer.current)
          return 100
        }
        return Math.min(100, p + 9 + Math.random() * 14)
      })
    }, 120)
  }, [])
  useEffect(() => () => window.clearInterval(loadTimer.current), [])

  const navigate = (input: string) => {
    const t = input.trim()
    if (!t) return
    const isUrl = !t.includes(' ') && t.includes('.')
    const target = isUrl ? t.replace(/^https?:\/\//, '') : `google.com/search?q=${encodeURIComponent(t)}`
    setUrl(target)
    setAddr(target)
    setPage('web')
    setTab(0)
    setQuery('')
    setPlaying(false)
    setVideos([])
    setSheetOpen(false)
    setHistory((h) => [hostOf(target), ...h.filter((x) => x !== hostOf(target))].slice(0, 20))
    startLoading()
  }

  const goHome = () => {
    setPage('home')
    setMenuOpen(false)
  }

  const isStarred = bookmarks.some((b) => b.url === hostOf(url))
  const toggleStar = () => {
    const h = hostOf(url)
    setBookmarks((b) =>
      b.some((x) => x.url === h) ? b.filter((x) => x.url !== h) : [{ url: h, title: h.split('.')[0].replace(/^./, (c) => c.toUpperCase()) }, ...b],
    )
  }

  const startPlay = () => {
    if (playing) return
    setPlaying(true)
    window.setTimeout(() => {
      setVideos(DETECTED)
      say('4 flux détectés')
    }, 1100)
  }

  /* ---- téléchargements : MAX_PARALLEL = 2 ---- */
  const addDownload = (v: Video) => {
    if (dlsRef.current.some((d) => d.id === v.id)) return
    const next = [...dlsRef.current, { ...v, doneMB: 0, speed: 0, state: 'queued' as const }]
    dlsRef.current = next
    setDls(next)
    say('Ajouté aux téléchargements')
  }

  useEffect(() => {
    const id = window.setInterval(() => {
      const cur = dlsRef.current
      if (!cur.length) return
      let running = 0
      const finished: Dl[] = []
      const next: Dl[] = []
      for (const d of cur) {
        let item = d
        if (d.state !== 'paused') {
          if (running < 2) {
            running++
            const target = 7 + Math.random() * 5
            const speed = d.speed ? d.speed * 0.6 + target * 0.4 : target
            const doneMB = Math.min(d.sizeMB, d.doneMB + speed * 0.2)
            item = { ...d, state: 'downloading', speed, doneMB }
            if (doneMB >= d.sizeMB) {
              finished.push(item)
              continue
            }
          } else item = { ...d, state: 'queued', speed: 0 }
        }
        next.push(item)
      }
      dlsRef.current = next
      setDls(next)
      if (finished.length) {
        setLib((l) => [
          ...finished.map((f) => ({
            id: 'n' + f.id + Date.now(),
            title: f.title + ` (${f.quality})`,
            sizeMB: f.sizeMB,
            duration: '03:24',
            isNew: true,
            hue: Math.floor(Math.random() * 360),
            priv: false,
          })),
          ...l,
        ])
        say('Téléchargement terminé — Movies/VidGrab')
      }
    }, 200)
    return () => window.clearInterval(id)
  }, [say])

  const setDlState = (id: string, state: Dl['state']) => {
    const next = dlsRef.current.map((d) => (d.id === id ? { ...d, state, speed: 0 } : d))
    dlsRef.current = next
    setDls(next)
  }
  const cancelDl = (id: string) => {
    const next = dlsRef.current.filter((d) => d.id !== id)
    dlsRef.current = next
    setDls(next)
  }

  /* ---- bibliothèque / dossier privé ---- */
  const shown = useMemo(() => {
    const list = lib.filter((l) => l.priv === inVault)
    if (sortBy === 'name') return [...list].sort((a, b) => a.title.localeCompare(b.title))
    if (sortBy === 'size') return [...list].sort((a, b) => b.sizeMB - a.sizeMB)
    return list
  }, [lib, inVault, sortBy])

  const hasPin = () => !!localStorage.getItem('vg_pin')
  const openLock = () => {
    if (inVault) return setInVault(false)
    setPin('')
    setPin2('')
    setPinErr('')
    setPinMode(hasPin() ? 'enter' : 'create')
  }
  const submitPin = async () => {
    if (pin.length < 4) return setPinErr('Au moins 4 chiffres')
    if (pinMode === 'create') {
      if (pin !== pin2) return setPinErr('Les codes ne correspondent pas')
      const salt = crypto.getRandomValues(new Uint8Array(8)).join('')
      localStorage.setItem('vg_pin', JSON.stringify({ salt, hash: await sha256(salt, pin) }))
      setPinMode(null)
      setInVault(true)
      say('Code PIN créé (SHA-256 + sel)')
    } else {
      const s = JSON.parse(localStorage.getItem('vg_pin') || '{}')
      if ((await sha256(s.salt, pin)) === s.hash) {
        setPinMode(null)
        setInVault(true)
      } else setPinErr('Code incorrect')
    }
  }

  const play = (l: Lib) => {
    setLib((x) => x.map((i) => (i.id === l.id ? { ...i, isNew: false } : i)))
    setPlayer(l)
    setItemMenu(null)
  }

  /* ---------------------------------------------------------------- */
  /* Rendu                                                             */
  /* ---------------------------------------------------------------- */
  const suggestions = query.trim()
    ? {
        fav: bookmarks.filter((b) => (b.title + b.url).toLowerCase().includes(query.toLowerCase())).slice(0, 3),
        hist: history.filter((h) => h.includes(query.toLowerCase())).slice(0, 3),
      }
    : null

  const TabCounter = (
    <button
      onClick={() => setTabsOpen(true)}
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-zinc-200 text-sm font-bold text-zinc-800 active:scale-95"
      aria-label="Onglets"
    >
      {tabCount}
    </button>
  )

  const host = hostOf(url)
  const isSearch = url.startsWith('google.com')
  const activeFab = videos.length > 0

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden bg-[#f7f7fa] text-zinc-900" onClick={() => { setBmMenu(null); setItemMenu(null) }}>
      {/* barre d'état */}
      <div className="flex h-6 shrink-0 items-center justify-between px-5 pt-1 text-[10px] font-semibold text-zinc-700">
        <span>9:41</span>
        <span className="flex gap-1 opacity-80">
          <Icon name="bolt" size={11} /> 5G
        </span>
      </div>

      <div className="relative min-h-0 flex-1">
        {/* ===================== ONGLET 0 : NAVIGATEUR ===================== */}
        {tab === 0 && page === 'home' && (
          <div className="flex h-full flex-col">
            <div className="flex items-center gap-1 px-3 py-1">
              {TabCounter}
              <div className="flex-1" />
              <button className="rounded-full p-2 hover:bg-zinc-200" onClick={() => setHelpOpen(true)} aria-label="Aide"><Icon name="help" size={22} /></button>
              <button className="rounded-full p-2 hover:bg-zinc-200" onClick={() => setSettingsOpen(true)} aria-label="Paramètres"><Icon name="settings" size={22} /></button>
              <div className="relative">
                <button className="rounded-full p-2 hover:bg-zinc-200" onClick={(e) => { e.stopPropagation(); setHomeMenu((v) => !v) }} aria-label="Menu"><Icon name="more" size={22} /></button>
                {homeMenu && (
                  <div className="fade-in absolute right-0 top-10 z-30 w-48 rounded-2xl bg-white p-1 text-sm shadow-2xl ring-1 ring-black/5">
                    <MenuItem icon="add" label="Nouvel onglet" onClick={() => { setTabCount((c) => c + 1); setHomeMenu(false); say('Nouvel onglet') }} />
                    <MenuItem icon="delete" label="Effacer l'historique" onClick={() => { setHistory([]); setHomeMenu(false) }} />
                    <MenuItem icon="help" label="Comment télécharger" onClick={() => { setHelpOpen(true); setHomeMenu(false) }} />
                  </div>
                )}
              </div>
            </div>

            <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-4 pb-2">
              <h1 className="mt-1 text-center text-[30px] font-black tracking-tight text-[#e53935]" style={{ textShadow: '0 4px 0 #b71c1c33, 0 10px 18px #e5393555' }}>
                VidGrab
              </h1>

              {/* Recherche intelligente */}
              <form
                className="mt-3 flex items-center gap-2 rounded-full bg-white px-4 py-2.5 shadow-lg shadow-zinc-300/70"
                onSubmit={(e) => { e.preventDefault(); navigate(query) }}
              >
                <Icon name="search" size={20} className="text-zinc-500" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Rechercher ou inscrire l'URL"
                  className="min-w-0 flex-1 bg-transparent text-[13px] outline-none placeholder:text-zinc-400"
                />
                {query && (
                  <>
                    <button type="button" onClick={() => setQuery('')} aria-label="Effacer"><Icon name="close" size={18} className="text-zinc-500" /></button>
                    <button type="submit" aria-label="Valider"><Icon name="arrow" size={20} className="text-[#e53935]" /></button>
                  </>
                )}
              </form>

              {suggestions ? (
                <div className="fade-in mt-2 overflow-hidden rounded-2xl bg-white shadow-xl shadow-zinc-300/60">
                  {suggestions.fav.map((b) => <SugRow key={'f' + b.url} icon="star" color="#ffb300" title={b.title} sub={b.url} onClick={() => navigate(b.url)} />)}
                  {suggestions.hist.map((h) => <SugRow key={'h' + h} icon="history" color="#3f51b5" title={h} sub="Historique" onClick={() => navigate(h)} />)}
                  {google.map((g) => <SugRow key={'g' + g} icon="search" color="#e53935" title={g} onClick={() => navigate(g)} />)}
                </div>
              ) : (
                <>
                  {/* raccourcis */}
                  <div className="mt-5 flex justify-between">
                    {SHORTCUTS.map((s) => (
                      <Tilt key={s.name} max={22} onClick={() => navigate(s.url)} className="flex w-[54px] flex-col items-center">
                        <div className="flex h-[50px] w-[50px] items-center justify-center rounded-full text-2xl font-bold text-white shadow-lg shadow-black/30" style={{ background: s.bg }}>{s.glyph}</div>
                        <span className="mt-1.5 text-[9.5px] font-medium text-zinc-600">{s.name}</span>
                      </Tilt>
                    ))}
                  </div>

                  {/* favoris */}
                  <h2 className="mt-6 text-sm font-bold">Mes favoris</h2>
                  {bookmarks.length === 0 ? (
                    <p className="mt-2 text-[11px] text-zinc-500">Touchez l'étoile ★ dans la barre d'adresse pour ajouter un site.</p>
                  ) : (
                    <div className="no-scrollbar mt-2 flex gap-4 overflow-x-auto pb-1 pt-1">
                      {bookmarks.map((b) => (
                        <div key={b.url} className="relative">
                          <Tilt max={18} className="flex w-[58px] flex-col items-center" onClick={() => navigate(b.url)}>
                            <div onContextMenu={(e) => { e.preventDefault(); setBmMenu(b.url) }}>
                              <Initial label={b.title} color={colorFor(b.url)} />
                            </div>
                            <span className="mt-1.5 w-full truncate text-center text-[10px]">{b.title}</span>
                          </Tilt>
                          <button
                            className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-zinc-800 text-white"
                            onClick={(e) => { e.stopPropagation(); setBmMenu(bmMenu === b.url ? null : b.url) }}
                            aria-label="Options du favori"
                          ><Icon name="more" size={12} /></button>
                          {bmMenu === b.url && (
                            <div className="fade-in absolute left-0 top-12 z-20 w-36 rounded-xl bg-white p-1 text-xs shadow-2xl ring-1 ring-black/5" onClick={(e) => e.stopPropagation()}>
                              <MenuItem icon="edit" label="Renommer" onClick={() => {
                                const n = window.prompt('Nouveau nom', b.title)
                                if (n) setBookmarks((x) => x.map((i) => (i.url === b.url ? { ...i, title: n } : i)))
                                setBmMenu(null)
                              }} />
                              <MenuItem icon="delete" label="Supprimer" onClick={() => { setBookmarks((x) => x.filter((i) => i.url !== b.url)); setBmMenu(null) }} />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* récents */}
                  <div className="mt-5 flex items-center">
                    <h2 className="flex-1 text-sm font-bold">Sites web récemment utilisés</h2>
                    {history.length > 0 && <button className="text-[11px] font-semibold text-[#e53935]" onClick={() => setHistory([])}>Effacer</button>}
                  </div>
                  {history.length === 0 ? (
                    <p className="mt-2 text-[11px] text-zinc-500">Aucun site récent.</p>
                  ) : (
                    <div className="mt-2 flex justify-between">
                      {history.slice(0, 5).map((h) => (
                        <Tilt key={h} max={18} className="flex w-[52px] flex-col items-center" onClick={() => navigate(h)}>
                          <Initial label={h} color={colorFor(h)} size={46} />
                          <span className="mt-1.5 w-full truncate text-center text-[9.5px]">{h.split('.')[0]}</span>
                        </Tilt>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="p-3">
              <Tilt max={5}>
                <button onClick={() => setHelpOpen(true)} className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-[#e53935] text-sm font-bold text-white shadow-lg shadow-red-500/40">
                  <Icon name="help" size={20} /> Comment télécharger
                </button>
              </Tilt>
            </div>
          </div>
        )}

        {tab === 0 && page === 'web' && (
          <div className="flex h-full flex-col">
            <div className="flex items-center gap-1 px-2 py-1">
              {TabCounter}
              <button className="rounded-full p-1.5 hover:bg-zinc-200" onClick={goHome} aria-label="Accueil"><Icon name="home" size={22} /></button>
              <form
                className="flex h-9 min-w-0 flex-1 items-center rounded-full bg-zinc-200 pl-3"
                onSubmit={(e) => { e.preventDefault(); navigate(addr) }}
              >
                <input value={addr} onChange={(e) => setAddr(e.target.value)} className="min-w-0 flex-1 bg-transparent text-[11.5px] outline-none" />
                <button type="button" onClick={toggleStar} className="p-1" aria-label="Favori">
                  <Icon name={isStarred ? 'star' : 'starBorder'} size={19} style={{ color: isStarred ? '#ffb300' : '#71717a' }} />
                </button>
                <button type="button" className="p-1 pr-2" aria-label="Arrêter" onClick={() => { if (progress < 100) setProgress(100); else setAddr('') }}>
                  <Icon name="close" size={17} className="text-zinc-600" />
                </button>
              </form>
              <div className="relative">
                <button className="rounded-full p-1.5 hover:bg-zinc-200" onClick={(e) => { e.stopPropagation(); setMenuOpen((v) => !v) }} aria-label="Menu"><Icon name="more" size={22} /></button>
                {menuOpen && (
                  <div className="fade-in absolute right-0 top-10 z-30 w-56 rounded-2xl bg-white p-1 text-xs shadow-2xl ring-1 ring-black/5" onClick={(e) => e.stopPropagation()}>
                    <MenuItem icon="desktop" label="Version ordinateur" right={<span className={cn('h-4 w-4 rounded border-2', desktop ? 'border-[#e53935] bg-[#e53935]' : 'border-zinc-400')} />} onClick={() => { setDesktop((d) => !d); setMenuOpen(false); startLoading(); say(!desktop ? 'User-Agent Chrome Desktop + rechargement' : 'User-Agent mobile + rechargement') }} />
                    <MenuItem icon="refresh" label="Actualiser" onClick={() => { setMenuOpen(false); startLoading() }} />
                    <MenuItem icon="share" label="Partager le lien" onClick={() => { setMenuOpen(false); say('Lien partagé') }} />
                    <MenuItem icon="open" label="Ouvrir dans le navigateur externe" onClick={() => { setMenuOpen(false); say('Ouverture externe') }} />
                    <MenuItem icon="delete" label="Tout effacer" onClick={() => { setMenuOpen(false); setVideos([]); setPlaying(false); say('Cookies et cache effacés') }} />
                  </div>
                )}
              </div>
            </div>
            <div className="h-[3px] w-full bg-transparent">
              {progress < 100 && <div className="h-full bg-[#e53935] transition-all duration-150" style={{ width: progress + '%' }} />}
            </div>

            {/* contenu "WebView" */}
            <div className="no-scrollbar relative min-h-0 flex-1 overflow-y-auto bg-white">
              {isSearch ? (
                <div className="space-y-4 p-4">
                  <div className="text-xs text-zinc-500">Environ 2 480 000 résultats</div>
                  {['Aurora time-lapse 4K — StreamHub', 'Télécharger des vidéos HLS — guide', 'Comment fonctionne le HLS ?'].map((t, i) => (
                    <div key={t}>
                      <div className="text-[11px] text-zinc-500">stream-demo.example › watch</div>
                      <button className="text-left text-[15px] font-medium text-blue-700 hover:underline" onClick={() => navigate('stream-demo.example/watch/' + i)}>{t}</button>
                      <p className="text-xs text-zinc-600">Regardez et téléchargez en 480p, 720p ou 1080p. Détection automatique des flux cachés.</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div>
                  <div className="bg-zinc-900 px-3 py-2 text-xs font-semibold text-white">{host} {desktop && <span className="ml-1 rounded bg-white/20 px-1.5 py-0.5 text-[9px]">DESKTOP</span>}</div>
                  <div className={cn('poster relative flex aspect-video items-center justify-center', 'bg-gradient-to-br from-indigo-700 via-fuchsia-600 to-orange-400')}>
                    {!playing ? (
                      <button onClick={startPlay} className="flex h-16 w-16 items-center justify-center rounded-full bg-white/90 text-[#e53935] shadow-2xl transition active:scale-90" aria-label="Lecture" style={{ transform: 'perspective(300px) rotateX(12deg)' }}>
                        <Icon name="play" size={34} />
                      </button>
                    ) : (
                      <div className="text-center text-white">
                        <div className="mx-auto mb-2 h-8 w-8 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                        <span className="text-[11px] font-medium">{videos.length ? 'Lecture…' : 'Analyse des requêtes réseau…'}</span>
                      </div>
                    )}
                    <div className="absolute bottom-2 right-2 rounded bg-black/60 px-1.5 py-0.5 text-[10px] text-white">37:39</div>
                  </div>
                  <div className="space-y-2 p-3">
                    <h3 className="text-sm font-bold">Aurora — Time-lapse 4K</h3>
                    <p className="text-xs text-zinc-500">1,2 M de vues • il y a 3 jours</p>
                    <div className="h-2 w-3/4 rounded bg-zinc-100" />
                    <div className="h-2 w-1/2 rounded bg-zinc-100" />
                    <p className="pt-2 text-[11px] text-zinc-500">
                      Prototype : le lecteur ci-dessus simule un flux HLS. Lancez la lecture pour voir le bouton de téléchargement s'allumer.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* FAB */}
            <div className="absolute bottom-4 right-4 z-20">
              <button
                onClick={() => (activeFab ? setSheetOpen(true) : say('Aucune vidéo détectée. Lancez la lecture.'))}
                className={cn(
                  'relative flex h-14 w-14 items-center justify-center rounded-full text-white shadow-xl transition-colors',
                  activeFab ? 'fab-active pulse-ring bg-[#e53935]' : 'bg-zinc-500',
                )}
                aria-label="Télécharger"
              >
                <Icon name="download" size={26} />
                {activeFab && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-white px-1 text-[11px] font-bold text-[#e53935] shadow">{videos.length}</span>}
              </button>
            </div>
          </div>
        )}

        {/* ===================== ONGLET 1 : PROGRESSION ===================== */}
        {tab === 1 && (
          <div className="flex h-full flex-col px-4">
            <h1 className="py-3 text-xl font-black tracking-[0.15em]">PROGRESSION</h1>
            {dls.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center pb-16">
                <div className="empty-spin">
                  <svg width="150" height="150" viewBox="0 0 150 150">
                    <defs>
                      <linearGradient id="eg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#e53935" stopOpacity=".22" /><stop offset="1" stopColor="#e53935" stopOpacity=".04" /></linearGradient>
                    </defs>
                    <rect x="8" y="8" width="134" height="134" rx="38" fill="url(#eg)" />
                    <circle cx="58" cy="68" r="28" fill="#dde1ee" />
                    <circle cx="88" cy="63" r="36" fill="#e9ecf6" />
                    <rect x="30" y="68" width="90" height="30" rx="15" fill="#e9ecf6" />
                    <path d="M75 117 54 90h15V63h12v27h15z" fill="#e53935" />
                  </svg>
                </div>
                <p className="mt-4 text-sm font-medium text-zinc-500">Aucun téléchargement en cours</p>
              </div>
            ) : (
              <div className="no-scrollbar min-h-0 flex-1 space-y-3 overflow-y-auto pb-3">
                {dls.map((d) => (
                  <Tilt key={d.id} max={5} className="rounded-3xl bg-white p-4 shadow-lg shadow-zinc-300/70">
                    <div className="line-clamp-2 text-[13px] font-semibold">{d.title}</div>
                    <div className="text-[10px] text-zinc-500">{d.kind} • {d.quality}</div>
                    <div className="mt-3 h-2 overflow-hidden rounded-full bg-zinc-200">
                      <div className="h-full rounded-full bg-gradient-to-r from-[#ff6b66] to-[#e53935] transition-[width] duration-200" style={{ width: (d.doneMB / d.sizeMB) * 100 + '%' }} />
                    </div>
                    <div className="mt-2 flex text-[11px]">
                      <span className="flex-1 font-bold text-[#e53935]">
                        {d.state === 'downloading' ? `${d.speed.toFixed(1)} Mo/s` : d.state === 'paused' ? 'En pause' : "En file d'attente"}
                      </span>
                      <span className="text-zinc-600">{fmtMB(d.doneMB)} / {fmtMB(d.sizeMB)}</span>
                    </div>
                    <div className="mt-1 flex justify-end gap-1">
                      {d.state === 'paused' ? (
                        <button className="rounded-full p-1.5 hover:bg-zinc-100" onClick={() => setDlState(d.id, 'queued')} aria-label="Reprendre"><Icon name="play" size={22} /></button>
                      ) : (
                        <button className="rounded-full p-1.5 hover:bg-zinc-100" onClick={() => setDlState(d.id, 'paused')} aria-label="Pause"><Icon name="pause" size={22} /></button>
                      )}
                      <button className="rounded-full p-1.5 text-red-600 hover:bg-zinc-100" onClick={() => cancelDl(d.id)} aria-label="Annuler"><Icon name="close" size={22} /></button>
                    </div>
                  </Tilt>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ===================== ONGLET 2 : TERMINÉ ===================== */}
        {tab === 2 && (
          <div className="flex h-full flex-col px-4">
            <div className="flex items-center py-3">
              <h1 className="flex-1 text-xl font-black tracking-[0.15em]">{inVault ? 'PRIVÉ' : 'TERMINÉ'}</h1>
              <button className="rounded-full p-2 hover:bg-zinc-200" onClick={openLock} aria-label="Dossier verrouillé">
                <Icon name="lock" size={22} className={inVault ? 'text-[#e53935]' : ''} />
              </button>
              <div className="relative">
                <button className="rounded-full p-2 hover:bg-zinc-200" onClick={(e) => { e.stopPropagation(); setSortMenu((v) => !v) }} aria-label="Trier"><Icon name="sort" size={22} /></button>
                {sortMenu && (
                  <div className="fade-in absolute right-0 top-10 z-30 w-40 rounded-2xl bg-white p-1 text-xs shadow-2xl ring-1 ring-black/5" onClick={(e) => e.stopPropagation()}>
                    {(['date', 'name', 'size'] as const).map((s) => (
                      <MenuItem key={s} icon={sortBy === s ? 'check' : 'sort'} label={'Trier par ' + (s === 'date' ? 'date' : s === 'name' ? 'nom' : 'taille')} onClick={() => { setSortBy(s); setSortMenu(false) }} />
                    ))}
                  </div>
                )}
              </div>
            </div>
            {shown.length === 0 ? (
              <div className="flex flex-1 items-center justify-center text-sm text-zinc-500">{inVault ? 'Le dossier privé est vide' : 'Aucune vidéo téléchargée'}</div>
            ) : (
              <div className="no-scrollbar min-h-0 flex-1 space-y-3 overflow-y-auto pb-3">
                {shown.map((l) => (
                  <Tilt key={l.id} max={5} className="relative rounded-3xl bg-white p-2.5 shadow-lg shadow-zinc-300/70" onClick={() => play(l)}>
                    <div className="flex items-center gap-2.5">
                      <div className="relative aspect-video w-[118px] shrink-0 overflow-hidden rounded-2xl" style={{ background: `linear-gradient(135deg,hsl(${l.hue} 70% 45%),hsl(${(l.hue + 60) % 360} 70% 25%))` }}>
                        <div className="absolute inset-0 flex items-center justify-center text-white/70"><Icon name="play" size={30} /></div>
                        {l.isNew && <span className="absolute left-1 top-1 rounded-md bg-[#e53935] px-1.5 py-0.5 text-[9px] font-bold text-white">Nouveau</span>}
                        <span className="absolute bottom-1 right-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[9px] text-white">{l.duration}</span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="line-clamp-2 text-[12.5px] font-semibold leading-tight">{l.title}</div>
                        <div className="mt-1 text-[10.5px] text-zinc-500">{fmtMB(l.sizeMB)}</div>
                      </div>
                      <button className="shrink-0 rounded-full p-1.5 hover:bg-zinc-100" onClick={(e) => { e.stopPropagation(); setItemMenu(itemMenu === l.id ? null : l.id) }} aria-label="Actions"><Icon name="more" size={20} /></button>
                    </div>
                    {itemMenu === l.id && (
                      <div className="fade-in absolute right-2 top-10 z-30 w-52 rounded-2xl bg-white p-1 text-xs shadow-2xl ring-1 ring-black/10" onClick={(e) => e.stopPropagation()}>
                        <MenuItem icon="play" label="Lire" onClick={() => play(l)} />
                        <MenuItem icon="edit" label="Renommer" onClick={() => { setRenaming(l); setRenameVal(l.title); setItemMenu(null) }} />
                        <MenuItem icon="share" label="Partager" onClick={() => { setItemMenu(null); say('Partage…') }} />
                        <MenuItem icon="lock" label={l.priv ? 'Sortir du dossier privé' : 'Déplacer vers le dossier privé'} onClick={() => {
                          setItemMenu(null)
                          if (!l.priv && !hasPin()) { setPin(''); setPin2(''); setPinErr(''); setPinMode('create'); return }
                          setLib((x) => x.map((i) => (i.id === l.id ? { ...i, priv: !i.priv } : i)))
                          say(l.priv ? 'Retour dans Movies/VidGrab' : 'Déplacé vers filesDir/private (.nomedia)')
                        }} />
                        <MenuItem icon="delete" label="Supprimer" onClick={() => { setLib((x) => x.filter((i) => i.id !== l.id)); setItemMenu(null) }} />
                      </div>
                    )}
                  </Tilt>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ===================== BARRE DE NAVIGATION ===================== */}
      <nav className="flex h-[62px] shrink-0 items-center justify-around border-t border-zinc-200 bg-white/95 px-2">
        {([
          ['globe', 'Onglet'],
          ['cloud', 'Progression'],
          ['library', 'Terminé'],
        ] as const).map(([ic, label], i) => (
          <button key={label} onClick={() => setTab(i as 0 | 1 | 2)} className="flex flex-1 flex-col items-center gap-0.5 py-1" aria-label={label}>
            <span className={cn('relative flex h-7 w-14 items-center justify-center rounded-full transition-all', tab === i ? 'bg-[#ffe3e1] text-[#b71c1c]' : 'text-zinc-500')}>
              <Icon name={ic} size={22} />
              {i === 1 && dls.length > 0 && <span className="absolute right-1.5 top-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#e53935] px-1 text-[9px] font-bold text-white">{dls.length}</span>}
            </span>
            <span className={cn('text-[10.5px]', tab === i ? 'font-bold' : 'text-zinc-500')}>{label}</span>
          </button>
        ))}
      </nav>
      <div className="mx-auto mb-1 h-1 w-24 shrink-0 rounded-full bg-zinc-800/80" />

      {/* ===================== OVERLAYS ===================== */}
      {sheetOpen && (
        <div className="fade-in absolute inset-0 z-40 flex items-end bg-black/45" onClick={() => setSheetOpen(false)}>
          <div className="sheet-up max-h-[75%] w-full overflow-y-auto rounded-t-3xl bg-white p-4 pb-6" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-zinc-300" />
            <h3 className="mb-3 text-base font-bold">Vidéos détectées ({videos.length})</h3>
            <div className="space-y-2.5">
              {videos.map((v) => {
                const added = dls.some((d) => d.id === v.id)
                return (
                  <Tilt key={v.id} max={6} className="flex items-center gap-3 rounded-2xl bg-zinc-50 p-3 shadow-md shadow-zinc-300/60">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#ffe3e1] text-[#e53935]"><Icon name={v.kind === 'HLS' ? 'layers' : 'library'} size={22} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-semibold">{v.title}</div>
                      <div className="text-[11px] text-zinc-500">{v.kind} • {v.quality} • {fmtMB(v.sizeMB)}</div>
                    </div>
                    <button disabled={added} onClick={(e) => { e.stopPropagation(); addDownload(v) }} className="flex h-10 w-10 items-center justify-center rounded-full bg-[#e53935] text-white disabled:bg-zinc-300" aria-label="Télécharger">
                      <Icon name={added ? 'check' : 'download'} size={20} />
                    </button>
                  </Tilt>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {tabsOpen && (
        <div className="fade-in absolute inset-0 z-40 flex flex-col bg-[#f7f7fa]">
          <div className="flex items-center px-4 py-3">
            <h2 className="flex-1 text-base font-black tracking-widest">{tabCount} ONGLET{tabCount > 1 ? 'S' : ''}</h2>
            <button className="mr-2 flex items-center gap-1 rounded-full bg-[#ffe3e1] px-3 py-1.5 text-xs font-bold text-[#b71c1c]" onClick={() => { setTabCount((c) => c + 1); setTabsOpen(false); setPage('home') }}><Icon name="add" size={16} />Nouveau</button>
            <button onClick={() => setTabsOpen(false)} aria-label="Fermer"><Icon name="close" size={22} /></button>
          </div>
          <div className="no-scrollbar grid grid-cols-2 gap-3 overflow-y-auto px-4 pb-4" style={{ perspective: 700 }}>
            {Array.from({ length: tabCount }).map((_, i) => (
              <div key={i} onClick={() => setTabsOpen(false)} className="cursor-pointer overflow-hidden rounded-2xl bg-white shadow-xl ring-2 ring-[#e53935]/0 transition hover:ring-[#e53935]" style={{ transform: `rotateY(${i % 2 === 0 ? 10 : -10}deg)`, transformOrigin: i % 2 === 0 ? 'left' : 'right' }}>
                <div className="flex items-center px-2.5 pt-1.5">
                  <span className="flex-1 truncate text-[11px] font-semibold">{i === tabCount - 1 && page === 'web' ? host : 'Accueil'}</span>
                  <button onClick={(e) => { e.stopPropagation(); if (tabCount > 1) setTabCount((c) => c - 1) }} aria-label="Fermer l'onglet"><Icon name="close" size={14} /></button>
                </div>
                <div className="m-2 flex h-28 items-center justify-center rounded-xl bg-gradient-to-br from-zinc-100 to-zinc-200 text-zinc-400"><Icon name={i === tabCount - 1 && page === 'web' ? 'globe' : 'home'} size={34} /></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {helpOpen && (
        <Modal title="Comment télécharger" onClose={() => setHelpOpen(false)} action="Compris">
          <ol className="space-y-2 text-[12.5px] text-zinc-700">
            <li><b>1.</b> Ouvrez un site de vidéos (Vimeo, Dailymotion, Facebook…).</li>
            <li><b>2.</b> Lancez la lecture de la vidéo.</li>
            <li><b>3.</b> Le bouton de téléchargement s'allume et affiche le nombre de flux détectés.</li>
            <li><b>4.</b> Touchez-le, choisissez la qualité puis « Télécharger ».</li>
            <li><b>5.</b> Suivez l'avancement dans « Progression », retrouvez le fichier dans « Terminé ».</li>
          </ol>
          <p className="mt-3 text-xs font-bold text-[#e53935]">YouTube n'est pas pris en charge.</p>
        </Modal>
      )}

      {settingsOpen && (
        <Modal title="Paramètres" onClose={() => setSettingsOpen(false)} action="OK">
          <div className="space-y-2 text-sm">
            <button className="block text-[#e53935]" onClick={() => { setHistory([]); say('Historique effacé') }}>Effacer l'historique</button>
            <button className="block text-[#e53935]" onClick={() => say('Cookies et cache effacés')}>Effacer cookies et cache</button>
            <p className="text-xs text-zinc-500">Dossier de sortie : Movies/VidGrab</p>
            <p className="text-xs text-zinc-500">Téléchargements simultanés : 2</p>
          </div>
        </Modal>
      )}

      {pinMode && (
        <Modal title={pinMode === 'create' ? 'Créer un code PIN' : 'Dossier privé'} onClose={() => setPinMode(null)} action="Valider" onAction={submitPin} keepOpen>
          <div className="space-y-2">
            <input autoFocus inputMode="numeric" type="password" maxLength={8} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} placeholder="Code PIN" className="w-full rounded-xl border border-zinc-300 px-3 py-2 text-sm outline-none focus:border-[#e53935]" />
            {pinMode === 'create' && <input inputMode="numeric" type="password" maxLength={8} value={pin2} onChange={(e) => setPin2(e.target.value.replace(/\D/g, ''))} placeholder="Confirmer" className="w-full rounded-xl border border-zinc-300 px-3 py-2 text-sm outline-none focus:border-[#e53935]" />}
            {pinErr && <p className="text-xs text-red-600">{pinErr}</p>}
            <p className="text-[10px] text-zinc-400">Haché en SHA-256 avec sel aléatoire.</p>
          </div>
        </Modal>
      )}

      {renaming && (
        <Modal title="Renommer" onClose={() => setRenaming(null)} action="OK" onAction={() => { setLib((x) => x.map((i) => (i.id === renaming.id ? { ...i, title: renameVal || i.title } : i))); setRenaming(null) }} keepOpen>
          <input value={renameVal} onChange={(e) => setRenameVal(e.target.value)} className="w-full rounded-xl border border-zinc-300 px-3 py-2 text-sm outline-none focus:border-[#e53935]" />
        </Modal>
      )}

      {player && <PlayerMock lib={player} onClose={() => setPlayer(null)} />}

      {toast && (
        <div className="fade-in pointer-events-none absolute bottom-24 left-1/2 z-50 -translate-x-1/2 whitespace-nowrap rounded-full bg-zinc-900/90 px-4 py-2 text-xs font-medium text-white shadow-xl">{toast}</div>
      )}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Petits composants                                                    */
/* ------------------------------------------------------------------ */
function MenuItem({ icon, label, onClick, right }: { icon: string; label: string; onClick: () => void; right?: ReactNode }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-[12.5px] hover:bg-zinc-100">
      <Icon name={icon} size={18} className="shrink-0 text-zinc-600" />
      <span className="flex-1">{label}</span>
      {right}
    </button>
  )
}

function SugRow({ icon, color, title, sub, onClick }: { icon: string; color: string; title: string; sub?: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-zinc-50">
      <Icon name={icon} size={20} style={{ color }} />
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[13px]">{title}</span>
        {sub && <span className="block truncate text-[10.5px] text-zinc-500">{sub}</span>}
      </span>
    </button>
  )
}

function Modal({ title, children, onClose, action, onAction, keepOpen }: { title: string; children: ReactNode; onClose: () => void; action: string; onAction?: () => void; keepOpen?: boolean }) {
  return (
    <div className="fade-in absolute inset-0 z-50 flex items-center justify-center bg-black/45 p-5" onClick={onClose}>
      <div className="w-full rounded-3xl bg-white p-5 shadow-2xl" onClick={(e) => e.stopPropagation()} style={{ transform: 'perspective(700px) rotateX(3deg)' }}>
        <h3 className="mb-3 text-lg font-bold">{title}</h3>
        {children}
        <div className="mt-4 flex justify-end gap-2 text-sm font-bold text-[#e53935]">
          {keepOpen && <button className="px-3 py-1.5" onClick={onClose}>Annuler</button>}
          <button className="px-3 py-1.5" onClick={() => { if (onAction) onAction(); if (!keepOpen) onClose() }}>{action}</button>
        </div>
      </div>
    </div>
  )
}

function PlayerMock({ lib, onClose }: { lib: Lib; onClose: () => void }) {
  const [playing, setPlaying] = useState(true)
  const [t, setT] = useState(0)
  const total = 600
  useEffect(() => {
    if (!playing) return
    const id = window.setInterval(() => setT((x) => Math.min(total, x + 1)), 1000)
    return () => window.clearInterval(id)
  }, [playing])
  const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(Math.floor(s % 60)).padStart(2, '0')}`
  return (
    <div className="fade-in absolute inset-0 z-[60] flex flex-col bg-black text-white">
      <div className="flex items-center p-3">
        <button onClick={onClose} aria-label="Fermer"><Icon name="close" size={24} /></button>
        <span className="ml-3 truncate text-xs font-medium">{lib.title}</span>
      </div>
      <div className="poster relative flex flex-1 items-center justify-center" style={{ background: `linear-gradient(135deg,hsl(${lib.hue} 70% 40%),hsl(${(lib.hue + 80) % 360} 70% 18%),hsl(${(lib.hue + 160) % 360} 60% 30%))` }}>
        <div className="flex items-center gap-6">
          <button onClick={() => setT((x) => Math.max(0, x - 10))} className="flex flex-col items-center text-[10px]" aria-label="Reculer de 10 secondes"><Icon name="replay" size={34} />10</button>
          <button onClick={() => setPlaying((p) => !p)} className="flex h-16 w-16 items-center justify-center rounded-full bg-white/20 backdrop-blur" aria-label="Lecture / pause"><Icon name={playing ? 'pause' : 'play'} size={36} /></button>
          <button onClick={() => setT((x) => Math.min(total, x + 10))} className="flex flex-col items-center text-[10px]" aria-label="Avancer de 10 secondes"><Icon name="replay" size={34} style={{ transform: 'scaleX(-1)' }} />10</button>
        </div>
      </div>
      <div className="space-y-1 p-4">
        <input type="range" min={0} max={total} value={t} onChange={(e) => setT(+e.target.value)} className="w-full accent-[#e53935]" aria-label="Progression" />
        <div className="flex items-center justify-between text-[11px] text-white/80">
          <span>{fmt(t)} / {fmt(total)}</span>
          <span className="flex items-center gap-2">Media3 ExoPlayer <Icon name="fullscreen" size={18} /></span>
        </div>
      </div>
    </div>
  )
}
