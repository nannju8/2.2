import { useRef, useState } from 'react'
import { PhoneApp } from './PhoneApp'
import { Icon } from './Icon'

/** Téléphone en 3D : suit le curseur, avec couches flottantes à des profondeurs différentes. */
export function Hero3D() {
  const ref = useRef<HTMLDivElement>(null)
  const [rot, setRot] = useState({ x: 6, y: -14 })
  const [hover, setHover] = useState(false)

  const onMove = (e: React.PointerEvent) => {
    const r = ref.current?.getBoundingClientRect()
    if (!r) return
    const nx = ((e.clientX - r.left) / r.width - 0.5) * 2
    const ny = ((e.clientY - r.top) / r.height - 0.5) * 2
    setRot({ x: -ny * 10, y: nx * 18 })
  }

  return (
    <div
      ref={ref}
      className="relative mx-auto flex items-center justify-center py-10"
      style={{ perspective: 1600, width: '100%', maxWidth: 620 }}
      onPointerMove={onMove}
      onPointerEnter={() => setHover(true)}
      onPointerLeave={() => {
        setHover(false)
        setRot({ x: 6, y: -14 })
      }}
    >
      {/* halo */}
      <div className="absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#e53935]/30 blur-[110px]" />

      <div
        className="preserve-3d relative"
        style={{
          transform: `rotateX(${rot.x}deg) rotateY(${rot.y}deg)`,
          transition: hover ? 'transform 0.1s ease-out' : 'transform 0.8s cubic-bezier(.2,.9,.3,1.2)',
        }}
      >
        {/* ombre portée */}
        <div
          className="absolute left-1/2 -bottom-10 h-10 w-[300px] -translate-x-1/2 rounded-[50%] bg-black/60 blur-2xl"
          style={{ transform: 'translateZ(-60px) rotateX(80deg)' }}
        />

        {/* tranche du téléphone (épaisseur) */}
        <div
          className="absolute inset-0 rounded-[48px] bg-gradient-to-b from-zinc-600 to-zinc-900"
          style={{ transform: 'translateZ(-14px)' }}
        />
        <div
          className="absolute inset-0 rounded-[48px] bg-zinc-800"
          style={{ transform: 'translateZ(-7px)' }}
        />

        {/* corps + écran */}
        <div
          className="relative overflow-hidden rounded-[48px] border-[10px] border-zinc-900 bg-zinc-900 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.8)] ring-1 ring-white/20"
          style={{ width: 330, height: 680 }}
        >
          <div className="absolute left-1/2 top-2 z-[70] h-[18px] w-[18px] -translate-x-1/2 rounded-full bg-black ring-1 ring-white/10" />
          <div className="h-full w-full overflow-hidden rounded-[38px]">
            <PhoneApp />
          </div>
        </div>

        {/* couches flottantes */}
        <div
          className="float-y absolute -left-24 top-24 hidden items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold backdrop-blur-md ring-1 ring-white/25 sm:flex"
          style={{ transform: 'translateZ(110px)' }}
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#e53935]"><Icon name="layers" size={18} /></span>
          HLS 1080p
        </div>
        <div
          className="float-y absolute -right-24 top-52 hidden items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold backdrop-blur-md ring-1 ring-white/25 sm:flex"
          style={{ transform: 'translateZ(150px)', animationDelay: '1.2s' }}
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-500"><Icon name="bolt" size={18} /></span>
          8 workers · 3 Mo
        </div>
        <div
          className="float-y absolute -left-20 bottom-28 hidden items-center gap-2 rounded-2xl bg-white/10 px-4 py-3 text-sm font-semibold backdrop-blur-md ring-1 ring-white/25 sm:flex"
          style={{ transform: 'translateZ(90px)', animationDelay: '2.1s' }}
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500"><Icon name="shield" size={18} /></span>
          Anti-pub actif
        </div>

        {/* cube 3D */}
        <div className="absolute -right-16 -top-4 hidden sm:block" style={{ transform: 'translateZ(180px)' }}>
          <div className="cube">
            {[
              'rotateY(0deg)',
              'rotateY(90deg)',
              'rotateY(180deg)',
              'rotateY(-90deg)',
              'rotateX(90deg)',
              'rotateX(-90deg)',
            ].map((t, i) => (
              <div key={i} className="cube-face" style={{ transform: `${t} translateZ(45px)` }}>
                <Icon name="download" size={38} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
